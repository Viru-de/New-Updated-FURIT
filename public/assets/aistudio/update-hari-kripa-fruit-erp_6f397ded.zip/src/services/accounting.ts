import { db } from './db';
import {
  CashSale,
  CrateLedgerEntry,
  CreditSale,
  Customer,
  LedgerEntry,
  Receipt,
  SaleProceeds,
  Vendor,
} from '../types';
import { compareDates, formatDate, toIsoDate } from '../utils/formatters';

export interface DateFilterRange {
  startDate?: string; // YYYY-MM-DD
  endDate?: string; // YYYY-MM-DD
}

/**
 * Computes the complete Sale Proceeds Ledger dynamically.
 * Starts with Opening Balance, then adds all Sale Proceeds in chronological order.
 * Credit increases balance, Debit decreases balance.
 */
export function getSaleProceedsLedger(filter?: DateFilterRange): {
  entries: LedgerEntry[];
  closingBalance: number;
  totalCredit: number;
  totalDebit: number;
} {
  const ob = db.getSaleProceedsOpeningBalance();
  const sales = db.getSaleProceeds();

  // Sort sales chronologically by date, then by sequence number
  const sortedSales = [...sales].sort((a, b) => {
    const dComp = compareDates(a.date, b.date);
    if (dComp !== 0) return dComp;
    return (a.sequenceNumber || 0) - (b.sequenceNumber || 0);
  });

  const entries: LedgerEntry[] = [];
  let currentBalance = 0;

  // 1. Opening Balance
  if (ob && ob.amount > 0) {
    const isCredit = ob.type === 'credit';
    const credit = isCredit ? ob.amount : null;
    const debit = isCredit ? null : ob.amount;
    currentBalance = isCredit ? ob.amount : -ob.amount;

    entries.push({
      id: ob.id,
      date: ob.date,
      particulars: ob.particulars || 'Opening Balance',
      referenceType: 'Opening Balance',
      debit,
      credit,
      balance: currentBalance,
    });
  }

  // 2. Sale Proceeds
  for (const sp of sortedSales) {
    const isCredit = sp.netAmount >= 0;
    const credit = isCredit ? sp.netAmount : null;
    const debit = isCredit ? null : Math.abs(sp.netAmount);
    currentBalance += sp.netAmount;

    entries.push({
      id: sp.id,
      date: sp.date,
      particulars: sp.proceedsNo,
      referenceType: 'Sale Proceeds',
      referenceId: sp.id,
      referenceNo: sp.proceedsNo,
      debit,
      credit,
      balance: currentBalance,
      notes: sp.notes,
      subDetails: {
        qty: sp.quantity,
        rate: sp.rate,
        items: sp.items?.map(it => ({
          name: it.fruitName,
          qty: it.quantity,
          unit: it.unit,
          rate: it.rate,
          amount: it.amount
        })),
        expenses: sp.expenses?.map(e => ({ name: e.name, amount: e.amount })),
      },
    });
  }

  // Filter if date range provided
  let filteredEntries = entries;
  if (filter?.startDate || filter?.endDate) {
    filteredEntries = entries.filter((e) => {
      const eDate = toIsoDate(e.date);
      if (filter.startDate && eDate < filter.startDate) return false;
      if (filter.endDate && eDate > filter.endDate) return false;
      return true;
    });
  }

  // Recalculate totals strictly from the applicable transactions in date range
  const totalCredit = filteredEntries.reduce((sum, e) => sum + (e.credit || 0), 0);
  const totalDebit = filteredEntries.reduce((sum, e) => sum + (e.debit || 0), 0);
  const closingBalance = filteredEntries.length > 0
    ? filteredEntries[filteredEntries.length - 1].balance
    : (entries.length > 0 ? entries[entries.length - 1].balance : currentBalance);

  return {
    entries: filteredEntries,
    closingBalance,
    totalCredit,
    totalDebit,
  };
}

/**
 * Computes an individual Customer's Ledger.
 * Debit increases customer outstanding, Credit reduces customer outstanding.
 */
export function getCustomerLedger(
  customerId: string,
  filter?: DateFilterRange
): {
  customer: Customer | undefined;
  entries: LedgerEntry[];
  closingBalance: number;
  totalDebit: number;
  totalCredit: number;
  overallClosingBalance?: number;
} {
  const customer = db.getCustomerById(customerId);
  const creditSales = db.getCreditSales().filter((cs) => cs.customerId === customerId);
  const cashSales = db.getCashSales().filter((cs) => cs.customerId === customerId);
  const receipts = db.getReceipts().filter((r) => r.customerId === customerId);
  const saleProceeds = db.getSaleProceeds().filter((sp) => sp.customerId === customerId);

  interface RawTx {
    id: string;
    date: string;
    createdAt: string;
    type: 'CREDIT_SALE' | 'CASH_SALE' | 'RECEIPT' | 'SALE_PROCEEDS';
    data: CreditSale | CashSale | Receipt | SaleProceeds;
  }

  const rawTxList: RawTx[] = [
    ...creditSales.map((cs) => ({
      id: cs.id,
      date: cs.date,
      createdAt: cs.createdAt,
      type: 'CREDIT_SALE' as const,
      data: cs,
    })),
    ...cashSales.map((cs) => ({
      id: cs.id,
      date: cs.date,
      createdAt: cs.createdAt,
      type: 'CASH_SALE' as const,
      data: cs,
    })),
    ...receipts.map((r) => ({
      id: r.id,
      date: r.date,
      createdAt: r.createdAt,
      type: 'RECEIPT' as const,
      data: r,
    })),
    ...saleProceeds.map((sp) => ({
      id: sp.id,
      date: sp.date,
      createdAt: sp.createdAt,
      type: 'SALE_PROCEEDS' as const,
      data: sp,
    })),
  ];

  // Sort transactions chronologically
  rawTxList.sort((a, b) => {
    const dComp = compareDates(a.date, b.date);
    if (dComp !== 0) return dComp;
    return (a.createdAt || '').localeCompare(b.createdAt || '');
  });

  const entries: LedgerEntry[] = [];
  let currentBalance = 0;

  // 1. Customer Opening Balance
  if (customer && customer.openingBalance !== 0) {
    const isDebit = customer.openingBalanceType === 'debit';
    const debit = isDebit ? customer.openingBalance : null;
    const credit = isDebit ? null : customer.openingBalance;
    currentBalance = isDebit ? customer.openingBalance : -customer.openingBalance;

    entries.push({
      id: `ob-${customer.id}`,
      date: customer.createdAt ? customer.createdAt.split('T')[0] : '2026-10-01',
      particulars: 'Opening Balance',
      referenceType: 'Opening Balance',
      debit,
      credit,
      balance: currentBalance,
    });
  } else if (customer) {
    // Show 0 opening balance row
    entries.push({
      id: `ob-${customer.id}`,
      date: customer.createdAt ? customer.createdAt.split('T')[0] : '2026-10-01',
      particulars: 'Opening Balance',
      referenceType: 'Opening Balance',
      debit: null,
      credit: null,
      balance: 0,
    });
  }

  // 2. Transactions
  for (const tx of rawTxList) {
    if (tx.type === 'CREDIT_SALE') {
      const cs = tx.data as CreditSale;
      const debit = cs.finalAmount;
      currentBalance += debit;

      entries.push({
        id: cs.id,
        date: cs.date,
        particulars: cs.creditSaleNo,
        referenceType: 'Credit Sale',
        referenceId: cs.id,
        referenceNo: cs.creditSaleNo,
        debit,
        credit: null,
        balance: currentBalance,
        notes: cs.notes,
        subDetails: {
          items: cs.items?.map(it => ({
            name: it.fruitName,
            qty: it.quantity,
            unit: it.unit,
            rate: it.rate,
            amount: it.amount
          })),
          expenses: cs.expenses?.map(e => ({ name: e.name, amount: e.amount })),
          crateIn: cs.crateIn,
          crateOut: cs.crateOut,
        },
      });
    } else if (tx.type === 'CASH_SALE') {
      const cs = tx.data as CashSale;
      // Cash Sale is settled immediately; it records transaction history but does not increase outstanding due
      entries.push({
        id: cs.id,
        date: cs.date,
        particulars: `${cs.cashSaleNo} (Cash Paid)`,
        referenceType: 'Cash Sale',
        referenceId: cs.id,
        referenceNo: cs.cashSaleNo,
        debit: cs.finalAmount,
        credit: cs.finalAmount, // Immediate settlement offset
        balance: currentBalance, // Outstanding remains unchanged
        notes: cs.notes,
        subDetails: {
          items: cs.items?.map(it => ({
            name: it.fruitName,
            qty: it.quantity,
            unit: it.unit,
            rate: it.rate,
            amount: it.amount
          })),
          expenses: cs.expenses?.map(e => ({ name: e.name, amount: e.amount })),
          crateIn: cs.crateIn,
          crateOut: cs.crateOut,
        },
      });
    } else if (tx.type === 'RECEIPT') {
      const r = tx.data as Receipt;
      const credit = r.amount;
      currentBalance -= credit;

      entries.push({
        id: r.id,
        date: r.date,
        particulars: `${r.receiptNo} (${r.paymentMode})`,
        referenceType: 'Receipt',
        referenceId: r.id,
        referenceNo: r.receiptNo,
        debit: null,
        credit,
        balance: currentBalance,
        notes: r.notes,
      });
    } else if (tx.type === 'SALE_PROCEEDS') {
      const sp = tx.data as SaleProceeds;
      const isCredit = sp.netAmount >= 0;
      const credit = isCredit ? sp.netAmount : null;
      const debit = isCredit ? null : Math.abs(sp.netAmount);
      
      // Net proceeds credited to customer ledger reduces due, negative net proceeds increases due
      if (credit) currentBalance -= credit;
      if (debit) currentBalance += debit;

      entries.push({
        id: sp.id,
        date: sp.date,
        particulars: sp.proceedsNo,
        referenceType: 'Sale Proceeds',
        referenceId: sp.id,
        referenceNo: sp.proceedsNo,
        debit,
        credit,
        balance: currentBalance,
        notes: sp.notes,
        subDetails: {
          qty: sp.quantity,
          rate: sp.rate,
          items: sp.items?.map(it => ({
            name: it.fruitName,
            qty: it.quantity,
            unit: it.unit,
            rate: it.rate,
            amount: it.amount
          })),
          expenses: sp.expenses?.map(e => ({ name: e.name, amount: e.amount })),
        },
      });
    }
  }

  let filteredEntries = entries;
  if (filter?.startDate || filter?.endDate) {
    filteredEntries = entries.filter((e) => {
      const eDate = toIsoDate(e.date);
      if (filter.startDate && eDate < filter.startDate) return false;
      if (filter.endDate && eDate > filter.endDate) return false;
      return true;
    });
  }

  // Recalculate totals strictly from the applicable transactions in date range
  const totalDebit = filteredEntries.reduce((sum, e) => sum + (e.debit || 0), 0);
  const totalCredit = filteredEntries.reduce((sum, e) => sum + (e.credit || 0), 0);
  const closingBalance = filteredEntries.length > 0
    ? filteredEntries[filteredEntries.length - 1].balance
    : (entries.length > 0 ? entries[entries.length - 1].balance : 0);

  return {
    customer,
    entries: filteredEntries,
    closingBalance,
    totalDebit,
    totalCredit,
    overallClosingBalance: currentBalance,
  };
}

/**
 * Computes an individual Customer's Crate Statement.
 * Separate quantity ledger.
 * Balance = Opening + OUT - IN
 */
export function getCustomerCrateStatement(
  customerId: string,
  filter?: DateFilterRange
): {
  customer: Customer | undefined;
  entries: CrateLedgerEntry[];
  closingCrates: number;
  crateWeightKg: number;
  closingTotalKg: number;
} {
  const customer = db.getCustomerById(customerId);
  const creditSales = db.getCreditSales().filter((cs) => cs.customerId === customerId);
  const manualCrates = db.getCrateTransactions().filter((ct) => ct.customerId === customerId);
  const crateTypes = db.getCrateTypes();

  // Find crate weight
  const configuredCrateType = customer?.crateTypeId
    ? crateTypes.find((ct) => ct.id === customer.crateTypeId)
    : crateTypes[0];
  const defaultWeightKg = configuredCrateType ? configuredCrateType.defaultWeightKg : 20;
  const crateName = configuredCrateType ? configuredCrateType.name : 'Standard Crate';

  interface RawCrateItem {
    id: string;
    date: string;
    particulars: string;
    referenceNo: string;
    inQuantity: number;
    outQuantity: number;
    weightKg: number;
    createdAt: string;
  }

  const list: RawCrateItem[] = [];

  // 1. Credit sales with crate activity
  for (const cs of creditSales) {
    const inQty = cs.crateIn || 0;
    const outQty = cs.crateOut || 0;
    if (inQty > 0 || outQty > 0) {
      list.push({
        id: cs.id,
        date: cs.date,
        particulars: cs.creditSaleNo,
        referenceNo: cs.creditSaleNo,
        inQuantity: inQty,
        outQuantity: outQty,
        weightKg: cs.crateWeightKg || defaultWeightKg,
        createdAt: cs.createdAt,
      });
    }
  }

  // 1b. Cash sales with crate activity
  const cashSalesForCrates = db.getCashSales().filter((cs) => cs.customerId === customerId);
  for (const cs of cashSalesForCrates) {
    const inQty = cs.crateIn || 0;
    const outQty = cs.crateOut || 0;
    if (inQty > 0 || outQty > 0) {
      list.push({
        id: cs.id,
        date: cs.date,
        particulars: cs.cashSaleNo,
        referenceNo: cs.cashSaleNo,
        inQuantity: inQty,
        outQuantity: outQty,
        weightKg: cs.crateWeightKg || defaultWeightKg,
        createdAt: cs.createdAt,
      });
    }
  }

  // 2. Manual crate transactions
  for (const mt of manualCrates) {
    list.push({
      id: mt.id,
      date: mt.date,
      particulars: `${mt.referenceType}: ${mt.notes || ''}`.trim(),
      referenceNo: mt.referenceNo,
      inQuantity: mt.inQuantity || 0,
      outQuantity: mt.outQuantity || 0,
      weightKg: mt.weightKgPerCrate || defaultWeightKg,
      createdAt: mt.createdAt,
    });
  }

  list.sort((a, b) => {
    const dComp = compareDates(a.date, b.date);
    if (dComp !== 0) return dComp;
    return (a.createdAt || '').localeCompare(b.createdAt || '');
  });

  const entries: CrateLedgerEntry[] = [];
  let currentBalance = customer?.openingCrateBalance || 0;

  // Opening entry
  entries.push({
    id: `ob-crate-${customerId}`,
    date: customer?.createdAt ? customer.createdAt.split('T')[0] : '2026-10-01',
    particulars: 'Opening Crate Balance',
    referenceNo: 'OB',
    inQuantity: 0,
    outQuantity: 0,
    balance: currentBalance,
    crateName,
    weightKg: defaultWeightKg,
    totalKg: currentBalance * defaultWeightKg,
  });

  for (const item of list) {
    currentBalance = currentBalance + item.outQuantity - item.inQuantity;
    entries.push({
      id: item.id,
      date: item.date,
      particulars: item.particulars,
      referenceNo: item.referenceNo,
      inQuantity: item.inQuantity,
      outQuantity: item.outQuantity,
      balance: currentBalance,
      crateName,
      weightKg: item.weightKg,
      totalKg: currentBalance * item.weightKg,
    });
  }

  let filtered = entries;
  if (filter?.startDate || filter?.endDate) {
    filtered = entries.filter((e) => {
      const eDate = toIsoDate(e.date);
      if (filter.startDate && eDate < filter.startDate) return false;
      if (filter.endDate && eDate > filter.endDate) return false;
      return true;
    });
  }

  return {
    customer,
    entries: filtered,
    closingCrates: currentBalance,
    crateWeightKg: defaultWeightKg,
    closingTotalKg: currentBalance * defaultWeightKg,
  };
}

/**
 * Computes total outstanding for all customers
 */
export function getAllCustomerOutstandings(): {
  customer: Customer;
  openingBalance: number;
  totalDebit: number;
  totalCredit: number;
  closingBalance: number;
  crateBalance: number;
  crateKg: number;
}[] {
  const customers = db.getCustomers();
  return customers.map((c) => {
    const ledger = getCustomerLedger(c.id);
    const crateStmt = getCustomerCrateStatement(c.id);
    return {
      customer: c,
      openingBalance: c.openingBalanceType === 'debit' ? c.openingBalance : -c.openingBalance,
      totalDebit: ledger.totalDebit,
      totalCredit: ledger.totalCredit,
      closingBalance: ledger.closingBalance,
      crateBalance: crateStmt.closingCrates,
      crateKg: crateStmt.closingTotalKg,
    };
  });
}

/**
 * Computes dashboard statistics dynamically from real database records.
 */
export function getDashboardMetrics(selectedDateIso: string, datePreset: 'today' | 'yesterday' | 'week' | 'month' | 'all') {
  const saleProceeds = db.getSaleProceeds();
  const creditSales = db.getCreditSales();
  const receipts = db.getReceipts();
  const outstandings = getAllCustomerOutstandings();

  // Helper date match
  const isInRange = (dateStr: string) => {
    const iso = toIsoDate(dateStr);
    if (datePreset === 'all') return true;
    if (datePreset === 'today') return iso === selectedDateIso;
    if (datePreset === 'yesterday') {
      const d = new Date(selectedDateIso);
      d.setDate(d.getDate() - 1);
      const yesterdayIso = d.toISOString().split('T')[0];
      return iso === yesterdayIso;
    }
    if (datePreset === 'week') {
      const d = new Date(selectedDateIso);
      d.setDate(d.getDate() - 7);
      const weekAgoIso = d.toISOString().split('T')[0];
      return iso >= weekAgoIso && iso <= selectedDateIso;
    }
    if (datePreset === 'month') {
      const d = new Date(selectedDateIso);
      d.setDate(d.getDate() - 30);
      const monthAgoIso = d.toISOString().split('T')[0];
      return iso >= monthAgoIso && iso <= selectedDateIso;
    }
    return iso === selectedDateIso;
  };

  const periodSaleProceeds = saleProceeds.filter((sp) => isInRange(sp.date));
  const periodCreditSales = creditSales.filter((cs) => isInRange(cs.date));
  const periodReceipts = receipts.filter((r) => isInRange(r.date));

  const totalSaleProceeds = periodSaleProceeds.reduce((sum, sp) => sum + sp.netAmount, 0);
  const totalCreditSales = periodCreditSales.reduce((sum, cs) => sum + cs.finalAmount, 0);
  const totalReceipts = periodReceipts.reduce((sum, r) => sum + r.amount, 0);

  // Total expenses = sale proceeds expenses + credit sales expenses
  const saleExpenses = periodSaleProceeds.reduce((sum, sp) => sum + sp.totalExpense, 0);
  const creditExpenses = periodCreditSales.reduce((sum, cs) => sum + cs.expenseTotal, 0);
  const totalExpenses = saleExpenses + creditExpenses;

  // Net Profit = (Sale Proceeds Net + Credit Sales Product Total) - Expenses
  // In fruit wholesale commission / trading:
  // Revenue = Total Sales
  // Net Profit = (totalSaleProceeds + totalCreditSales) - totalExpenses
  const netProfit = (totalSaleProceeds + totalCreditSales) - totalExpenses;

  // Total Customer Outstanding
  const totalCustomerOutstanding = outstandings.reduce((sum, o) => sum + o.closingBalance, 0);

  // Total Crates
  const totalCrates = outstandings.reduce((sum, o) => sum + o.crateBalance, 0);

  // Wholesale Vendor Outstanding
  const vendors = db.getVendors();
  const totalVendorOutstanding = vendors.reduce((sum, v) => {
    return sum + (v.openingBalanceType === 'credit' ? v.openingBalance : -v.openingBalance);
  }, 0);

  return {
    saleProceedsCount: periodSaleProceeds.length,
    totalSaleProceeds,
    creditSalesCount: periodCreditSales.length,
    totalCreditSales,
    receiptsCount: periodReceipts.length,
    totalReceipts,
    totalExpenses,
    netProfit,
    totalCustomerOutstanding,
    totalVendorOutstanding,
    totalCrateBalance: totalCrates,
    recentSaleProceeds: periodSaleProceeds.slice(-5).reverse(),
    recentCreditSales: periodCreditSales.slice(-5).reverse(),
    recentReceipts: periodReceipts.slice(-5).reverse(),
  };
}
