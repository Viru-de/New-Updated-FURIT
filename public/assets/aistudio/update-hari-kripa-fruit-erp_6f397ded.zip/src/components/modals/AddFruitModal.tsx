import React, { useState } from 'react';
import { Fruit, CrateType } from '../../types';
import { db } from '../../services/db';
import { X, Plus, Package } from 'lucide-react';
import { FruitIconSelector } from '../common/FruitIconSelector';

interface AddFruitModalProps {
  isOpen: boolean;
  onClose: () => void;
  onFruitCreated: (fruit: Fruit) => void;
}

export const AddFruitModal: React.FC<AddFruitModalProps> = ({
  isOpen,
  onClose,
  onFruitCreated,
}) => {
  const [crateTypes, setCrateTypes] = useState<CrateType[]>(db.getCrateTypes());
  const units = db.getUnits();

  const [name, setName] = useState('');
  const [unit, setUnit] = useState(units[0]?.symbol || 'Crate');
  const [crateTypeId, setCrateTypeId] = useState(crateTypes[0]?.id || '');
  // Default Price must be 1 for new items, and user can edit manually
  const [price, setPrice] = useState<number | ''>(1);
  const [fruitIcon, setFruitIcon] = useState<string | undefined>(undefined);

  // Quick addition of custom crate sizes if needed
  const [isAddingNewCrateSize, setIsAddingNewCrateSize] = useState(false);
  const [newCrateSizeName, setNewCrateSizeName] = useState('');
  const [newCrateSizeWeight, setNewCrateSizeWeight] = useState<number | ''>(15);

  if (!isOpen) return null;

  const isCrate = unit.trim().toLowerCase() === 'crate';

  const handleAddNewCrateType = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCrateSizeName.trim()) return;
    const weight = Number(newCrateSizeWeight) || 10;
    const newCt: CrateType = {
      id: `ct-${Date.now()}`,
      name: newCrateSizeName.trim(),
      defaultWeightKg: weight,
      description: `${weight} Kg crate size`,
    };
    db.saveCrateType(newCt);
    const updated = db.getCrateTypes();
    setCrateTypes(updated);
    setCrateTypeId(newCt.id);
    setIsAddingNewCrateSize(false);
    setNewCrateSizeName('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const selectedCrate = isCrate ? crateTypes.find((c) => c.id === crateTypeId) : undefined;
    const crateWeightKg = isCrate && selectedCrate ? selectedCrate.defaultWeightKg : 20;

    const newFruit: Fruit = {
      id: `f-${Date.now()}`,
      name: name.trim(),
      unit,
      defaultUnit: unit, // for backward compatibility
      crateTypeId: isCrate ? (crateTypeId || undefined) : undefined,
      crateWeightKg,
      defaultRate: price !== '' ? Number(price) : 1, // Default price is 1
      fruitIcon,
      active: true,
      createdAt: new Date().toISOString(),
    };

    db.saveFruit(newFruit);
    onFruitCreated(newFruit);
    onClose();

    // Reset form for next use
    setName('');
    setUnit(units[0]?.symbol || 'Crate');
    setCrateTypeId(crateTypes[0]?.id || '');
    setPrice(1);
    setFruitIcon(undefined);
    setIsAddingNewCrateSize(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
      <div className="w-full max-w-md rounded-xl border border-slate-200 bg-white shadow-xl dark:border-slate-800 dark:bg-slate-900 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <Package className="h-5 w-5 text-emerald-600" />
            <h3 className="text-base font-semibold text-slate-900 dark:text-white">
              Add New Item
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 p-5">
          <div>
            <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Item Name <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              autoFocus
              placeholder="e.g. Alphonso Mango, Shimla Apple, Green Grapes"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
            />
          </div>

          {/* Item Icon / Image selection */}
          <FruitIconSelector
            value={fruitIcon}
            onChange={setFruitIcon}
            fruitName={name}
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Unit <span className="text-rose-500">*</span>
              </label>
              <select
                value={unit}
                onChange={(e) => {
                  const newUnit = e.target.value;
                  setUnit(newUnit);
                  if (newUnit.toLowerCase() !== 'crate') {
                    setIsAddingNewCrateSize(false);
                  }
                }}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              >
                {units.map((u) => (
                  <option key={u.id} value={u.symbol}>
                    {u.name} ({u.symbol})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Price (₹) <span className="text-rose-500">*</span>
              </label>
              <input
                type="number"
                min="0"
                step="any"
                required
                value={price}
                onChange={(e) => setPrice(e.target.value !== '' ? Number(e.target.value) : '')}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono-numbers text-slate-900 outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>
          </div>

          {/* Crate Type dropdown - shown ONLY when Unit is Crate */}
          {isCrate && (
            <div className="rounded-lg border border-sky-200 bg-sky-50/50 p-3 dark:border-sky-900/50 dark:bg-sky-950/20">
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-semibold text-sky-900 dark:text-sky-200">
                  Crate Type
                </label>
                <button
                  type="button"
                  onClick={() => setIsAddingNewCrateSize(!isAddingNewCrateSize)}
                  className="text-[11px] font-semibold text-sky-700 hover:text-sky-900 dark:text-sky-400"
                >
                  {isAddingNewCrateSize ? 'Cancel' : '+ Add Crate Size'}
                </button>
              </div>

              {!isAddingNewCrateSize ? (
                <select
                  value={crateTypeId}
                  onChange={(e) => setCrateTypeId(e.target.value)}
                  className="w-full rounded-lg border border-sky-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none focus:border-sky-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                >
                  {crateTypes.map((ct) => (
                    <option key={ct.id} value={ct.id}>
                      {ct.name} ({ct.defaultWeightKg} Kg)
                    </option>
                  ))}
                </select>
              ) : (
                <div className="space-y-2 pt-1 border-t border-sky-200 dark:border-sky-900">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] font-medium text-slate-600 dark:text-slate-400">
                        Crate Size Name
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. 12 Kg, 25 Kg"
                        value={newCrateSizeName}
                        onChange={(e) => setNewCrateSizeName(e.target.value)}
                        className="w-full rounded border border-slate-300 px-2 py-1 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-medium text-slate-600 dark:text-slate-400">
                        Weight (Kg)
                      </label>
                      <input
                        type="number"
                        min="1"
                        value={newCrateSizeWeight}
                        onChange={(e) => setNewCrateSizeWeight(e.target.value ? Number(e.target.value) : '')}
                        className="w-full rounded border border-slate-300 px-2 py-1 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                      />
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleAddNewCrateType}
                    className="rounded bg-sky-600 px-3 py-1 text-xs font-semibold text-white hover:bg-sky-700"
                  >
                    Save Crate Size
                  </button>
                </div>
              )}
              <p className="mt-1 text-[11px] text-sky-700 dark:text-sky-300">
                Selected crate size will be saved against this item.
              </p>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-300 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white shadow-xs hover:bg-emerald-700"
            >
              <Plus className="h-4 w-4" /> Save Item
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
