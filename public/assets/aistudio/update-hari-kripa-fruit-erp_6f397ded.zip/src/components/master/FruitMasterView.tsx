import React, { useState } from 'react';
import { Fruit, CrateType } from '../../types';
import { db } from '../../services/db';
import { formatCurrency } from '../../utils/formatters';
import { AddFruitModal } from '../modals/AddFruitModal';
import { FruitBadge } from '../common/FruitIconHelper';
import { FruitIconSelector } from '../common/FruitIconSelector';
import { ExcelActionBar } from '../common/ExcelActionBar';
import { exportFruitMaster } from '../../utils/excelEngine';
import {
  Search,
  Plus,
  Edit2,
  Trash2,
  AlertCircle,
  X,
  Package,
} from 'lucide-react';
import { AdminPasswordModal } from '../common/AdminPasswordModal';

export const FruitMasterView: React.FC = () => {
  const [fruits, setFruits] = useState<Fruit[]>(db.getFruits());
  const [crateTypes, setCrateTypes] = useState<CrateType[]>(db.getCrateTypes());
  const units = db.getUnits();

  const [searchTerm, setSearchTerm] = useState('');
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editingFruit, setEditingFruit] = useState<Fruit | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  // Edit modal state
  const [editName, setEditName] = useState('');
  const [editUnit, setEditUnit] = useState('Crate');
  const [editCrateTypeId, setEditCrateTypeId] = useState('');
  const [editPrice, setEditPrice] = useState<number | ''>(1);
  const [editFruitIcon, setEditFruitIcon] = useState<string | undefined>(undefined);

  // State for adding a new crate size directly
  const [isAddingNewCrateSize, setIsAddingNewCrateSize] = useState(false);
  const [newCrateSizeName, setNewCrateSizeName] = useState('');
  const [newCrateSizeWeight, setNewCrateSizeWeight] = useState<number | ''>(15);

  const refreshList = () => {
    setFruits(db.getFruits());
    setCrateTypes(db.getCrateTypes());
  };

  const handleEditClick = (f: Fruit) => {
    setEditingFruit(f);
    setEditName(f.name);
    const unitVal = f.unit || f.defaultUnit || 'Crate';
    setEditUnit(unitVal);
    setEditCrateTypeId(f.crateTypeId || crateTypes[0]?.id || '');
    // Preserve existing saved price; never overwrite with 1 on edit
    setEditPrice(typeof f.defaultRate === 'number' && !isNaN(f.defaultRate) ? f.defaultRate : 1);
    setEditFruitIcon(f.fruitIcon);
    setIsAddingNewCrateSize(false);
  };

  const handleAddNewCrateType = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCrateSizeName.trim()) return;
    const weight = Number(newCrateSizeWeight) || 10;
    const newCt: CrateType = {
      id: `ct-${Date.now()}`,
      name: newCrateSizeName.trim(),
      defaultWeightKg: weight,
      description: `${weight} Kg crate size`,
    };
    db.saveCrateType(newCt);
    const updatedCrates = db.getCrateTypes();
    setCrateTypes(updatedCrates);
    setEditCrateTypeId(newCt.id);
    setIsAddingNewCrateSize(false);
    setNewCrateSizeName('');
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingFruit || !editName.trim()) return;

    const isCrate = editUnit.trim().toLowerCase() === 'crate';
    const selectedCrate = isCrate ? crateTypes.find((c) => c.id === editCrateTypeId) : undefined;
    const crateWeightKg = isCrate && selectedCrate ? selectedCrate.defaultWeightKg : (editingFruit.crateWeightKg || 20);

    const updated: Fruit = {
      ...editingFruit,
      name: editName.trim(),
      unit: editUnit,
      defaultUnit: editUnit, // preserved for backward compatibility
      crateTypeId: isCrate ? (editCrateTypeId || undefined) : undefined,
      crateWeightKg,
      defaultRate: editPrice !== '' ? Number(editPrice) : 1,
      fruitIcon: editFruitIcon,
    };

    db.saveFruit(updated);
    setEditingFruit(null);
    refreshList();
  };

  const confirmDelete = () => {
    if (deleteId) {
      const fruit = fruits.find((f) => f.id === deleteId);
      if (fruit) {
        db.moveToTrash(
          'fruit',
          fruit.id,
          fruit.name,
          `Default Unit: ${fruit.defaultUnit || 'Crate'} · Rate: ₹${fruit.defaultRate}`,
          fruit
        );
      } else {
        db.deleteFruit(deleteId);
      }
      setDeleteId(null);
      refreshList();
    }
  };

  const isEditUnitCrate = editUnit.trim().toLowerCase() === 'crate';

  const filtered = fruits.filter((f) => {
    const q = searchTerm.toLowerCase().trim();
    return f.name.toLowerCase().includes(q);
  });

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            Fruit / Item Master
          </h2>
          <p className="text-xs text-slate-500">
            Wholesale item catalog, standard units, crate sizes & default item prices
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <ExcelActionBar
            module="fruitMaster"
            moduleTitle="Fruit / Item Master"
            onExportFiltered={() => exportFruitMaster(filtered, '_Filtered')}
            onExportAll={() => exportFruitMaster(fruits)}
            filteredCount={filtered.length}
            totalCount={fruits.length}
            onImportComplete={refreshList}
          />
          <button
            type="button"
            onClick={() => setIsAddOpen(true)}
            className="flex items-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white shadow-xs hover:bg-emerald-700"
          >
            <Plus className="h-4 w-4" /> + Add New Item
          </button>
        </div>
      </div>

      {/* Search by Item Name */}
      <div className="flex items-center rounded-xl border border-slate-200 bg-white px-3 py-2 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
        <Search className="h-4 w-4 text-slate-400 mr-2 shrink-0" />
        <input
          type="text"
          placeholder="Search by item name (e.g. Apple, Strawberry, Mango)..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full text-xs text-slate-900 outline-none placeholder:text-slate-400 dark:bg-slate-900 dark:text-white"
        />
      </div>

      {/* Items Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {filtered.map((fruit) => {
          const unit = fruit.unit || fruit.defaultUnit || 'Crate';
          const isCrate = unit.toLowerCase() === 'crate';
          const crateType = isCrate ? crateTypes.find((ct) => ct.id === fruit.crateTypeId) : null;

          return (
            <div
              key={fruit.id}
              className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-4 shadow-2xs transition-all hover:border-slate-300 dark:border-slate-800 dark:bg-slate-900"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <FruitBadge
                      fruitIcon={fruit.fruitIcon}
                      fruitName={fruit.name}
                      size="md"
                    />
                    <div className="min-w-0">
                      <h3 className="font-bold text-sm text-slate-900 truncate dark:text-white">
                        {fruit.name}
                      </h3>
                      <span className="text-[11px] font-medium text-emerald-700 dark:text-emerald-400 block truncate">
                        Unit: {unit}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleEditClick(fruit)}
                      className="p-1 text-slate-400 hover:text-slate-700"
                      title="Edit Item"
                    >
                      <Edit2 className="h-3.5 w-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setDeleteId(fruit.id)}
                      className="p-1 text-slate-400 hover:text-rose-600"
                      title="Delete Item"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>

                <div className="space-y-1.5 rounded-lg border border-slate-100 bg-slate-50 p-2.5 text-xs dark:border-slate-800 dark:bg-slate-800/40">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Unit:</span>
                    <span className="font-semibold text-slate-800 dark:text-slate-200">
                      {unit}
                    </span>
                  </div>

                  {isCrate && (
                    <div className="flex justify-between">
                      <span className="text-slate-500">Crate Type:</span>
                      <span className="font-semibold text-sky-700 dark:text-sky-300">
                        {crateType ? crateType.name : (fruit.crateWeightKg ? `${fruit.crateWeightKg} Kg Crate` : 'Standard Crate')}
                      </span>
                    </div>
                  )}

                  <div className="flex justify-between">
                    <span className="text-slate-500">Price:</span>
                    <span className="font-mono-numbers font-bold text-emerald-600 dark:text-emerald-400">
                      {formatCurrency(fruit.defaultRate)}
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-3 pt-2 text-[11px] text-slate-400 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span>{isCrate && crateType ? crateType.name : unit}</span>
                <span className="text-emerald-600 font-medium">Active</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Item Modal */}
      <AddFruitModal
        isOpen={isAddOpen}
        onClose={() => setIsAddOpen(false)}
        onFruitCreated={refreshList}
      />

      {/* Edit Item Modal */}
      {editingFruit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-xl border border-slate-200 bg-white shadow-xl dark:border-slate-800 dark:bg-slate-900 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4 dark:border-slate-800">
              <h3 className="text-base font-semibold text-slate-900 dark:text-white">
                Edit Item
              </h3>
              <button
                type="button"
                onClick={() => setEditingFruit(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-4 p-5">
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Item Name *
                </label>
                <input
                  type="text"
                  required
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              {/* Item Icon / Image selection */}
              <FruitIconSelector
                value={editFruitIcon}
                onChange={setEditFruitIcon}
                fruitName={editName}
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Unit *
                  </label>
                  <select
                    value={editUnit}
                    onChange={(e) => {
                      const newUnit = e.target.value;
                      setEditUnit(newUnit);
                      if (newUnit.toLowerCase() !== 'crate') {
                        setIsAddingNewCrateSize(false);
                      }
                    }}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    {units.map((u) => (
                      <option key={u.id} value={u.symbol}>
                        {u.name} ({u.symbol})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Price (₹)
                  </label>
                  <input
                    type="number"
                    step="any"
                    min="0"
                    required
                    value={editPrice}
                    onChange={(e) => setEditPrice(e.target.value !== '' ? Number(e.target.value) : '')}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono-numbers text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              {/* Crate Type selection - shown ONLY when Unit is Crate */}
              {isEditUnitCrate && (
                <div className="rounded-lg border border-sky-200 bg-sky-50/50 p-3 dark:border-sky-900/50 dark:bg-sky-950/20">
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="block text-xs font-semibold text-sky-900 dark:text-sky-200">
                      Crate Type
                    </label>
                    <button
                      type="button"
                      onClick={() => setIsAddingNewCrateSize(!isAddingNewCrateSize)}
                      className="text-[11px] font-semibold text-sky-700 hover:text-sky-900 dark:text-sky-400"
                    >
                      {isAddingNewCrateSize ? 'Cancel' : '+ Add Crate Size'}
                    </button>
                  </div>

                  {!isAddingNewCrateSize ? (
                    <select
                      value={editCrateTypeId}
                      onChange={(e) => setEditCrateTypeId(e.target.value)}
                      className="w-full rounded-lg border border-sky-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none focus:border-sky-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                    >
                      {crateTypes.map((ct) => (
                        <option key={ct.id} value={ct.id}>
                          {ct.name} ({ct.defaultWeightKg} Kg)
                        </option>
                      ))}
                    </select>
                  ) : (
                    <div className="space-y-2 pt-1 border-t border-sky-200 dark:border-sky-900">
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[10px] font-medium text-slate-600 dark:text-slate-400">
                            Crate Size Name
                          </label>
                          <input
                            type="text"
                            placeholder="e.g. 12 Kg, 25 Kg"
                            value={newCrateSizeName}
                            onChange={(e) => setNewCrateSizeName(e.target.value)}
                            className="w-full rounded border border-slate-300 px-2 py-1 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-medium text-slate-600 dark:text-slate-400">
                            Weight (Kg)
                          </label>
                          <input
                            type="number"
                            min="1"
                            value={newCrateSizeWeight}
                            onChange={(e) => setNewCrateSizeWeight(e.target.value ? Number(e.target.value) : '')}
                            className="w-full rounded border border-slate-300 px-2 py-1 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                          />
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={handleAddNewCrateType}
                        className="rounded bg-sky-600 px-3 py-1 text-xs font-semibold text-white hover:bg-sky-700"
                      >
                        Save Crate Size
                      </button>
                    </div>
                  )}
                  <p className="mt-1 text-[11px] text-sky-700 dark:text-sky-300">
                    Selected crate size will be saved against this item.
                  </p>
                </div>
              )}

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingFruit(null)}
                  className="rounded-lg border border-slate-300 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Password-Protected Delete confirmation */}
      <AdminPasswordModal
        isOpen={!!deleteId}
        title="Delete Fruit / Item?"
        itemTitle={fruits.find((f) => f.id === deleteId)?.name}
        description="The fruit item will be moved to the Trash / Recycle Bin. You can restore it anytime without affecting transaction history."
        confirmText="Verify & Move to Trash"
        onConfirm={confirmDelete}
        onClose={() => setDeleteId(null)}
      />
    </div>
  );
};
