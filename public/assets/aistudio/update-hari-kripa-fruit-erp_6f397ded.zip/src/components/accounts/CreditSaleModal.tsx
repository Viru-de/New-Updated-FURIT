import React, { useState, useEffect, useMemo, useRef } from 'react';
import { CreditSale, CreditSaleItem, Customer, ExpenseItem, Fruit } from '../../types';
import { db } from '../../services/db';
import { getCustomerLedger } from '../../services/accounting';
import { formatCurrency, formatSequence, getTodayIso } from '../../utils/formatters';
import { isCrateUnit } from '../../utils/crateUtils';
import { calculateSaleCrateSummary, formatQtyWithUnit, calculateWholesaleItemAmount } from '../../utils/billingCalculations';
import { getFruitEffectivePrice } from '../../utils/fruitUtils';
import { DatePickerInput } from '../common/DatePickerInput';
import { AddCustomerModal } from '../modals/AddCustomerModal';
import { X, Plus, Trash2, UserPlus, Calculator } from 'lucide-react';

interface CreditSaleModalProps {
  isOpen: boolean;
  onClose: () => void;
  editItem?: CreditSale | null;
  onSaved: (item: CreditSale) => void;
  preselectedCustomerId?: string;
}

const COMMON_UNITS = ['Crate', 'Box', 'DABBA', 'Peti', 'KG', 'Bag', 'Carton'];

export const CreditSaleModal: React.FC<CreditSaleModalProps> = ({
  isOpen,
  onClose,
  editItem,
  onSaved,
  preselectedCustomerId,
}) => {
  const customers = db.getCustomers();
  const fruitsCatalog = db.getFruits();

  // Basic info
  const [customerId, setCustomerId] = useState('');
  const [date, setDate] = useState(getTodayIso());
  const [notes, setNotes] = useState('');

  // Bill items
  const [items, setItems] = useState<CreditSaleItem[]>([]);

  // Expenses: Freight, Hamali, Others
  const [freight, setFreight] = useState<number | ''>(100);
  const [hamali, setHamali] = useState<number | ''>(100);
  const [othersExpense, setOthersExpense] = useState<number | ''>(50);

  // Financial summary
  const [oldBalance, setOldBalance] = useState<number>(0);
  const [cashReceipt, setCashReceipt] = useState<number | ''>('');

  // Auto-suggestion state for each row
  const [activeSuggestionRow, setActiveSuggestionRow] = useState<number | null>(null);

  const [isAddCustomerOpen, setIsAddCustomerOpen] = useState(false);
  const suggestionContainerRef = useRef<HTMLDivElement | null>(null);

  // Initialize or reset form
  useEffect(() => {
    if (!isOpen) return;

    if (editItem) {
      setCustomerId(editItem.customerId);
      setDate(editItem.date);
      setNotes(editItem.notes || '');

      // Load items
      const loadedItems: CreditSaleItem[] = (editItem.items || []).map((it, idx) => {
        const kgVal = it.kg !== undefined ? it.kg : 0;
        const rateVal = it.rate || 0;
        const calculatedAmount = calculateWholesaleItemAmount(it.quantity || 1, it.unit || 'Crate', kgVal, rateVal);
        return {
          id: it.id || `csi-${Date.now()}-${idx}`,
          fruitId: it.fruitId,
          fruitName: it.fruitName || '',
          quantity: it.quantity || 1,
          unit: it.unit || 'Crate',
          kg: kgVal,
          rate: rateVal,
          amount: it.amount !== undefined ? it.amount : calculatedAmount,
          crateSize: it.crateSize,
        };
      });
      setItems(loadedItems);

      // Load expenses
      const fExp = editItem.expenses?.find((e) => e.name.toLowerCase().includes('freight'));
      const hExp = editItem.expenses?.find((e) => e.name.toLowerCase().includes('hamali'));
      const oExp = editItem.expenses?.find((e) => !e.name.toLowerCase().includes('freight') && !e.name.toLowerCase().includes('hamali'));

      setFreight(fExp ? fExp.amount : (editItem.expenses && editItem.expenses[0] ? editItem.expenses[0].amount : 100));
      setHamali(hExp ? hExp.amount : (editItem.expenses && editItem.expenses[1] ? editItem.expenses[1].amount : 100));
      setOthersExpense(oExp ? oExp.amount : (editItem.expenses && editItem.expenses[2] ? editItem.expenses[2].amount : 50));

      // Calculate old balance before this edit bill
      try {
        const ledger = getCustomerLedger(editItem.customerId);
        const billDebit = editItem.finalAmount || 0;
        const prevReceipt = editItem.cashReceipt || 0;
        // Old balance = Current closing balance - Bill Debit + Previous Cash Receipt
        const computedOld = Math.round((ledger.closingBalance - billDebit + prevReceipt) * 100) / 100;
        setOldBalance(editItem.oldBalance !== undefined ? editItem.oldBalance : computedOld);
      } catch {
        setOldBalance(editItem.oldBalance || 0);
      }

      setCashReceipt(editItem.cashReceipt !== undefined && editItem.cashReceipt > 0 ? editItem.cashReceipt : '');
    } else {
      const initialCustId = preselectedCustomerId || customers[0]?.id || '';
      setCustomerId(initialCustId);
      setDate(getTodayIso());
      setNotes('');

      // Default rows matching wholesale mandi reference pattern
      setItems([
        {
          id: `csi-${Date.now()}-1`,
          fruitName: 'ANAR',
          quantity: 20,
          unit: 'Crate',
          kg: 400,
          rate: 50,
          amount: 20000,
        },
        {
          id: `csi-${Date.now()}-2`,
          fruitName: 'GRAPES BLACK 10 KG',
          quantity: 10,
          unit: 'Crate',
          kg: 200,
          rate: 50,
          amount: 10000,
        },
      ]);

      setFreight(100);
      setHamali(100);
      setOthersExpense(50);
      setCashReceipt('');

      if (initialCustId) {
        try {
          const ledger = getCustomerLedger(initialCustId);
          setOldBalance(ledger.closingBalance);
        } catch {
          setOldBalance(0);
        }
      } else {
        setOldBalance(0);
      }
    }
  }, [isOpen, editItem, preselectedCustomerId]);

  // Update customer balance when customer selection changes (for new bills)
  const handleCustomerChange = (newCustId: string) => {
    setCustomerId(newCustId);
    if (!newCustId) {
      setOldBalance(0);
      return;
    }
    try {
      const ledger = getCustomerLedger(newCustId);
      if (editItem && editItem.customerId === newCustId) {
        const billDebit = editItem.finalAmount || 0;
        const prevReceipt = editItem.cashReceipt || 0;
        setOldBalance(Math.round((ledger.closingBalance - billDebit + prevReceipt) * 100) / 100);
      } else {
        setOldBalance(ledger.closingBalance);
      }
    } catch {
      setOldBalance(0);
    }
  };

  // Close suggestion dropdown on outside click
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (
        suggestionContainerRef.current &&
        !suggestionContainerRef.current.contains(e.target as Node)
      ) {
        setActiveSuggestionRow(null);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  // Row change handler with calculation rules:
  // - Crate: Amount = Kg × Rate when Kg > 0; if Kg is 0 or empty => Amount = 0
  // - All non-Crate units (Box, Peti, DABBA, etc.):
  //   If Kg is 0 or empty => Amount = Qty × Rate;
  //   If Kg > 0 => Amount = Kg × Rate.
  const handleItemChange = (index: number, field: keyof CreditSaleItem, val: any) => {
    const updated = [...items];
    const current = { ...updated[index] };

    if (field === 'fruitName') {
      current.fruitName = val;
    } else if (field === 'quantity') {
      const q = val === '' ? 0 : Number(val);
      current.quantity = isNaN(q) ? 0 : q;
    } else if (field === 'unit') {
      const prevWasCrate = isCrateUnit(current.unit);
      const nextUnit = String(val).trim();
      current.unit = nextUnit;
      // Changing the unit from Crate to Box, Peti, DABBA, or another unit sets Kg to 0 by default
      if (prevWasCrate && !isCrateUnit(nextUnit)) {
        current.kg = 0;
      }
    } else if (field === 'kg') {
      const k = val === '' ? 0 : Number(val);
      current.kg = isNaN(k) ? 0 : k;
    } else if (field === 'rate') {
      const r = val === '' ? 0 : Number(val);
      current.rate = isNaN(r) ? 0 : r;
    }

    // Live amount calculation: updates immediately whenever Qty, unit, Kg, or Rate changes
    current.amount = calculateWholesaleItemAmount(
      current.quantity,
      current.unit,
      current.kg,
      current.rate
    );

    updated[index] = current;
    setItems(updated);
  };

  // Selecting a fruit suggestion loads catalog details
  const handleSelectSuggestion = (index: number, fruit: Fruit) => {
    const updated = [...items];
    const current = { ...updated[index] };
    current.fruitId = fruit.id;
    current.fruitName = fruit.name;
    if (fruit.defaultUnit) {
      const prevWasCrate = isCrateUnit(current.unit);
      current.unit = fruit.defaultUnit;
      if (prevWasCrate && !isCrateUnit(fruit.defaultUnit)) {
        current.kg = 0;
      }
    }
    const rate = getFruitEffectivePrice(fruit);
    if (rate > 0) {
      current.rate = rate;
    }
    current.amount = calculateWholesaleItemAmount(
      current.quantity,
      current.unit,
      current.kg,
      current.rate
    );
    updated[index] = current;
    setItems(updated);
    setActiveSuggestionRow(null);
  };

  const handleAddRow = () => {
    setItems([
      ...items,
      {
        id: `csi-${Date.now()}-${items.length + 1}`,
        fruitName: '',
        quantity: 1,
        unit: 'Crate',
        kg: 0,
        rate: 0,
        amount: 0,
      },
    ]);
  };

  const handleRemoveRow = (index: number) => {
    if (items.length <= 1) {
      // Keep at least one empty row
      setItems([
        {
          id: `csi-${Date.now()}`,
          fruitName: '',
          quantity: 1,
          unit: 'Crate',
          kg: 0,
          rate: 0,
          amount: 0,
        },
      ]);
      return;
    }
    setItems(items.filter((_, i) => i !== index));
  };

  // Rule 4: Automatic Crate Balance
  // Sum ONLY rows where unit is 'Crate' (ignoring case and surrounding spaces).
  // Excludes Box, DABBA, and other units.
  const crateSummary = useMemo(() => {
    return calculateSaleCrateSummary(items);
  }, [items]);

  const totalCrateBalance = crateSummary.totalBalanceCrates;

  // Middle section: Expenses
  const numFreight = typeof freight === 'number' ? freight : (Number(freight) || 0);
  const numHamali = typeof hamali === 'number' ? hamali : (Number(hamali) || 0);
  const numOthers = typeof othersExpense === 'number' ? othersExpense : (Number(othersExpense) || 0);
  const totalExpense = Math.round((numFreight + numHamali + numOthers) * 100) / 100;

  // Right side: Financial Totals
  // Total = sum of all item Amount values
  const totalItemAmount = useMemo(() => {
    return items.reduce((sum, it) => sum + (Number(it.amount) || 0), 0);
  }, [items]);

  // Net Total = Total + Expense
  const netTotal = Math.round((totalItemAmount + totalExpense) * 100) / 100;

  // Cash Receipt
  const numCashReceipt = typeof cashReceipt === 'number' ? cashReceipt : (Number(cashReceipt) || 0);

  // Total Balance = Net Total + Old Balance - Cash Receipt
  const totalBalance = Math.round((netTotal + oldBalance - numCashReceipt) * 100) / 100;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerId) return;
    if (items.length === 0) return;

    const cust = customers.find((c) => c.id === customerId);
    const seq = editItem ? editItem.sequenceNumber : db.getNextCreditSaleNumber();
    const creditSaleNo = editItem
      ? editItem.creditSaleNo
      : `Credit Sale No. ${formatSequence(seq, 3)}`;

    // Prepare expenses array
    const expensesList: ExpenseItem[] = [
      { id: 'cse-1', name: 'Freight', amount: numFreight },
      { id: 'cse-2', name: 'Hamali', amount: numHamali },
      { id: 'cse-3', name: 'Others', amount: numOthers },
    ];

    const saleRecord: CreditSale = {
      id: editItem ? editItem.id : `cs-${Date.now()}`,
      creditSaleNo,
      sequenceNumber: seq,
      customerId,
      customerName: cust ? cust.name : 'Customer',
      date,
      items: items.map((it) => ({
        ...it,
        amount: calculateWholesaleItemAmount(it.quantity, it.unit, it.kg, it.rate),
      })),
      crateIn: 0,
      crateOut: totalCrateBalance,
      crateWeightKg: 20,
      expenses: expensesList,
      productTotal: totalItemAmount,
      expenseTotal: totalExpense,
      totalDebit: netTotal,
      finalAmount: netTotal, // Debit added to customer ledger
      netTotal,
      oldBalance,
      cashReceipt: numCashReceipt,
      totalBalance,
      totalCrateBalance,
      notes: notes.trim() || undefined,
      createdAt: editItem ? editItem.createdAt : new Date().toISOString(),
    };

    // Save credit sale to database
    db.saveCreditSale(saleRecord);

    // Synchronize Cash Receipt if entered
    const linkedReceiptId = `rec-cs-${saleRecord.id}`;
    if (numCashReceipt > 0) {
      db.saveReceipt({
        id: linkedReceiptId,
        receiptNo: `REC-CS-${formatSequence(saleRecord.sequenceNumber, 3)}`,
        sequenceNumber: db.getNextReceiptNumber(),
        customerId: saleRecord.customerId,
        customerName: saleRecord.customerName,
        date: saleRecord.date,
        paymentMode: 'Cash',
        amount: numCashReceipt,
        notes: `Cash Receipt against ${saleRecord.creditSaleNo}`,
        createdAt: saleRecord.createdAt,
      });
    } else {
      // Remove any previously recorded cash receipt if updated to 0
      db.deleteReceipt(linkedReceiptId);
    }

    onSaved(saleRecord);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-3 sm:p-4 backdrop-blur-xs">
        <div className="w-full max-w-4xl rounded-xl border border-slate-200 bg-white shadow-2xl dark:border-slate-800 dark:bg-slate-900 max-h-[94vh] overflow-y-auto">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-slate-100 px-5 py-3.5 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/50">
            <div className="flex items-center gap-2">
              <Calculator className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {editItem ? `Edit ${editItem.creditSaleNo}` : 'New Wholesale Credit Sale'}
                </h3>
                <p className="text-[11px] text-slate-500">
                  Wholesale Mandi Credit Bill · Amount = Kg × Rate · Automatic Crate Balance
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-200 hover:text-slate-700 dark:hover:bg-slate-800"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4">
            {/* Customer & Date Header */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 bg-slate-50 dark:bg-slate-800/40 p-3 rounded-lg border border-slate-200 dark:border-slate-800">
              <div>
                <div className="mb-1 flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                    Customer *
                  </label>
                  <button
                    type="button"
                    onClick={() => setIsAddCustomerOpen(true)}
                    className="flex items-center gap-1 text-[11px] font-semibold text-emerald-600 hover:text-emerald-700"
                  >
                    <UserPlus className="h-3 w-3" /> + Add Customer
                  </button>
                </div>
                <select
                  required
                  value={customerId}
                  onChange={(e) => handleCustomerChange(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs text-slate-900 outline-none focus:border-emerald-500 font-semibold dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                >
                  <option value="">-- Select Customer --</option>
                  {customers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} {c.mobile ? `(${c.mobile})` : ''} - {c.city || 'Mandi'}
                    </option>
                  ))}
                </select>
              </div>

              <DatePickerInput
                label="Date"
                required
                value={date}
                onChange={setDate}
              />
            </div>

            {/* Reference Bill Table: No. | Item Name | Qty & Unit | Kg | Rate | Amount */}
            <div className="rounded-lg border border-slate-200 dark:border-slate-800 overflow-hidden" ref={suggestionContainerRef}>
              <div className="bg-slate-100 dark:bg-slate-800 px-3 py-2 flex items-center justify-between border-b border-slate-200 dark:border-slate-700">
                <div className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                  Bill Items ({items.length})
                </div>
                <button
                  type="button"
                  onClick={handleAddRow}
                  className="flex items-center gap-1 rounded bg-emerald-600 text-white px-2.5 py-1 text-xs font-semibold hover:bg-emerald-700 shadow-2xs"
                >
                  <Plus className="h-3.5 w-3.5" /> + Add Row
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-bold uppercase text-slate-600 dark:border-slate-800 dark:bg-slate-800/60 dark:text-slate-400">
                      <th className="py-2 px-2 text-center w-10">No.</th>
                      <th className="py-2 px-2 min-w-[200px]">Item Name *</th>
                      <th className="py-2 px-2 min-w-[140px]">Qty & Unit</th>
                      <th className="py-2 px-2 w-24 text-right">Kg</th>
                      <th className="py-2 px-2 w-28 text-right">Rate (₹)</th>
                      <th className="py-2 px-2 w-28 text-right">Amount (₹)</th>
                      <th className="py-2 px-1 w-10 text-center"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {items.map((it, idx) => {
                      const filteredSuggestions = it.fruitName
                        ? fruitsCatalog.filter((f) =>
                            f.name.toLowerCase().includes(it.fruitName.toLowerCase())
                          )
                        : [];

                      return (
                        <tr key={it.id || idx} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                          {/* No. */}
                          <td className="py-2 px-2 text-center font-mono text-slate-500 font-bold">
                            {idx + 1}
                          </td>

                          {/* Item Name: Editable text input with suggestions from fruit catalog */}
                          <td className="py-2 px-2 relative">
                            <input
                              type="text"
                              required
                              placeholder="Type item name (e.g. ANAR, APPLE 125)..."
                              value={it.fruitName}
                              onFocus={() => setActiveSuggestionRow(idx)}
                              onChange={(e) => {
                                handleItemChange(idx, 'fruitName', e.target.value);
                                setActiveSuggestionRow(idx);
                              }}
                              className="w-full rounded border border-slate-300 bg-white px-2 py-1.5 text-xs font-semibold text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white uppercase"
                            />

                            {/* Dropdown Suggestions */}
                            {activeSuggestionRow === idx && filteredSuggestions.length > 0 && (
                              <div className="absolute left-2 right-2 top-11 z-30 max-h-48 overflow-y-auto rounded-lg border border-slate-200 bg-white shadow-xl dark:border-slate-700 dark:bg-slate-800">
                                <div className="p-1 text-[10px] uppercase font-bold text-slate-400 px-2 border-b border-slate-100 dark:border-slate-700">
                                  Fruit Catalog Matches
                                </div>
                                {filteredSuggestions.map((f) => (
                                  <button
                                    key={f.id}
                                    type="button"
                                    onClick={() => handleSelectSuggestion(idx, f)}
                                    className="w-full text-left px-2.5 py-1.5 text-xs hover:bg-emerald-50 hover:text-emerald-700 dark:hover:bg-slate-700 flex items-center justify-between border-b border-slate-50 dark:border-slate-700/50 last:border-none"
                                  >
                                    <span className="font-bold text-slate-800 dark:text-slate-100">
                                      {f.name}
                                    </span>
                                    <span className="text-[11px] text-slate-500">
                                      {f.defaultUnit || 'Crate'} · ₹{getFruitEffectivePrice(f)}
                                    </span>
                                  </button>
                                ))}
                              </div>
                            )}
                          </td>

                          {/* Qty & Unit */}
                          <td className="py-2 px-2">
                            <div className="flex items-center gap-1">
                              <input
                                type="number"
                                min="0"
                                step="any"
                                placeholder="Qty"
                                value={it.quantity === 0 ? '' : it.quantity}
                                onChange={(e) => handleItemChange(idx, 'quantity', e.target.value)}
                                className="w-16 rounded border border-slate-300 px-2 py-1.5 text-xs font-mono font-bold text-slate-900 text-right outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                              />
                              <input
                                type="text"
                                list={`unit-options-${idx}`}
                                placeholder="Unit"
                                value={it.unit}
                                onChange={(e) => handleItemChange(idx, 'unit', e.target.value)}
                                className="w-20 rounded border border-slate-300 px-2 py-1.5 text-xs font-semibold text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                              />
                              <datalist id={`unit-options-${idx}`}>
                                {COMMON_UNITS.map((u) => (
                                  <option key={u} value={u} />
                                ))}
                              </datalist>
                            </div>
                          </td>

                          {/* Kg (Customer actual weight) */}
                          <td className="py-2 px-2 text-right">
                            <input
                              type="number"
                              min="0"
                              step="any"
                              placeholder="0"
                              value={it.kg === 0 ? '' : it.kg}
                              onChange={(e) => handleItemChange(idx, 'kg', e.target.value)}
                              className="w-full rounded border border-slate-300 px-2 py-1.5 text-xs font-mono font-bold text-slate-900 text-right outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                            />
                          </td>

                          {/* Rate */}
                          <td className="py-2 px-2 text-right">
                            <div className="relative">
                              <span className="absolute left-2 top-1.5 text-[11px] text-slate-400">₹</span>
                              <input
                                type="number"
                                min="0"
                                step="any"
                                placeholder="0.00"
                                value={it.rate === 0 ? '' : it.rate}
                                onChange={(e) => handleItemChange(idx, 'rate', e.target.value)}
                                className="w-full rounded border border-slate-300 pl-5 pr-2 py-1.5 text-right font-mono font-medium text-xs text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                              />
                            </div>
                          </td>

                          {/* Amount: Read-only live calculated (Kg * Rate) */}
                          <td className="py-2 px-2 text-right">
                            <span className="font-mono font-bold text-xs text-slate-900 dark:text-white block py-1.5">
                              {formatCurrency(it.amount)}
                            </span>
                          </td>

                          {/* Action */}
                          <td className="py-2 px-1 text-center">
                            <button
                              type="button"
                              onClick={() => handleRemoveRow(idx)}
                              className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors"
                              title="Remove item"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Bottom quick actions */}
              <div className="bg-slate-50 dark:bg-slate-800/40 p-2 border-t border-slate-200 dark:border-slate-700 flex justify-between items-center text-xs">
                <button
                  type="button"
                  onClick={handleAddRow}
                  className="flex items-center gap-1 font-semibold text-emerald-600 hover:text-emerald-700"
                >
                  <Plus className="h-3.5 w-3.5" /> + Add Another Item
                </button>
                <div className="text-slate-500 font-medium text-[11px]">
                  * Crates calculate as <strong>Kg × Rate</strong> (₹0.00 if no weight). All other units (Box, Peti, DABBA, etc.) calculate as <strong>Qty × Rate</strong> (or <strong>Kg × Rate</strong> if weight is entered).
                </div>
              </div>
            </div>

            {/* Bottom Summary: 3 Sections matching reference bill */}
            <div className="rounded-lg border border-slate-300 bg-white dark:border-slate-800 dark:bg-slate-900 overflow-hidden shadow-xs">
              <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-slate-200 dark:divide-slate-800">
                {/* 1. Left Section: Crate Details */}
                <div className="p-3.5 bg-slate-50/50 dark:bg-slate-900/50 space-y-2">
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 border-b border-slate-200 dark:border-slate-800 pb-1">
                    Crate Summary
                  </div>
                  <div className="space-y-1 font-mono text-xs">
                    <div className="text-sm font-bold text-slate-900 dark:text-white">
                      Balance Crate: <span className="text-sky-600 dark:text-sky-400 font-extrabold">{totalCrateBalance}</span>
                    </div>

                    {/* Breakdown by size (e.g. 10Kg = 10, 20Kg = 20) */}
                    <div className="space-y-0.5 pt-1 text-slate-600 dark:text-slate-400">
                      {crateSummary.breakdown.length > 0 ? (
                        crateSummary.breakdown.map((b) => (
                          <div key={b.weightKg} className="flex justify-between">
                            <span>{b.weightKg}Kg =</span>
                            <span className="font-bold text-slate-900 dark:text-white">{b.count}</span>
                          </div>
                        ))
                      ) : (
                        <div className="text-slate-400 italic text-[11px]">
                          Only rows with unit &quot;Crate&quot; count towards crates
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* 2. Middle Section: Expenses (Freight, Hamali, Others) */}
                <div className="p-3.5 bg-slate-50/30 dark:bg-slate-900/30 space-y-2">
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 border-b border-slate-200 dark:border-slate-800 pb-1 flex justify-between">
                    <span>Expenses</span>
                    <span className="font-mono font-bold text-rose-600">{formatCurrency(totalExpense)}</span>
                  </div>

                  <div className="space-y-2 text-xs">
                    <div className="flex items-center justify-between gap-2">
                      <label className="text-slate-600 dark:text-slate-400 font-medium">Freight</label>
                      <div className="relative w-28">
                        <span className="absolute left-2 top-1 text-slate-400 text-[11px]">₹</span>
                        <input
                          type="number"
                          min="0"
                          step="any"
                          value={freight}
                          onChange={(e) => setFreight(e.target.value === '' ? '' : Number(e.target.value))}
                          className="w-full rounded border border-slate-300 pl-5 pr-2 py-1 text-right font-mono text-xs font-semibold text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between gap-2">
                      <label className="text-slate-600 dark:text-slate-400 font-medium">Hamali</label>
                      <div className="relative w-28">
                        <span className="absolute left-2 top-1 text-slate-400 text-[11px]">₹</span>
                        <input
                          type="number"
                          min="0"
                          step="any"
                          value={hamali}
                          onChange={(e) => setHamali(e.target.value === '' ? '' : Number(e.target.value))}
                          className="w-full rounded border border-slate-300 pl-5 pr-2 py-1 text-right font-mono text-xs font-semibold text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between gap-2">
                      <label className="text-slate-600 dark:text-slate-400 font-medium">Others</label>
                      <div className="relative w-28">
                        <span className="absolute left-2 top-1 text-slate-400 text-[11px]">₹</span>
                        <input
                          type="number"
                          min="0"
                          step="any"
                          value={othersExpense}
                          onChange={(e) => setOthersExpense(e.target.value === '' ? '' : Number(e.target.value))}
                          className="w-full rounded border border-slate-300 pl-5 pr-2 py-1 text-right font-mono text-xs font-semibold text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* 3. Right Section: Financial Totals */}
                <div className="p-3.5 space-y-1.5 text-xs font-medium">
                  <div className="flex justify-between items-center text-slate-600 dark:text-slate-400">
                    <span>Total (Items)</span>
                    <span className="font-mono font-bold text-slate-900 dark:text-white">
                      {formatCurrency(totalItemAmount)}
                    </span>
                  </div>

                  <div className="flex justify-between items-center text-slate-600 dark:text-slate-400">
                    <span>Expense</span>
                    <span className="font-mono font-bold text-slate-800 dark:text-slate-200">
                      +{formatCurrency(totalExpense)}
                    </span>
                  </div>

                  <div className="flex justify-between items-center border-t border-slate-200 dark:border-slate-800 pt-1 text-slate-800 dark:text-slate-200 font-bold">
                    <span>Net Total</span>
                    <span className="font-mono font-extrabold text-sm text-slate-900 dark:text-white">
                      {formatCurrency(netTotal)}
                    </span>
                  </div>

                  <div className="flex justify-between items-center text-slate-600 dark:text-slate-400 pt-1">
                    <span>Old Balance</span>
                    <span className="font-mono font-semibold text-slate-800 dark:text-slate-200">
                      {formatCurrency(oldBalance)}
                    </span>
                  </div>

                  <div className="flex justify-between items-center gap-2">
                    <span className="text-slate-600 dark:text-slate-400 font-semibold">Cash Receipt</span>
                    <div className="relative w-28">
                      <span className="absolute left-2 top-1 text-slate-400 text-[11px]">₹</span>
                      <input
                        type="number"
                        min="0"
                        step="any"
                        placeholder="0.00"
                        value={cashReceipt}
                        onChange={(e) => setCashReceipt(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full rounded border border-emerald-400 pl-5 pr-2 py-1 text-right font-mono text-xs font-bold text-emerald-700 outline-none focus:border-emerald-600 dark:bg-slate-800 dark:text-emerald-400"
                      />
                    </div>
                  </div>

                  <div className="flex justify-between items-center border-t-2 border-slate-300 dark:border-slate-700 pt-1.5 font-bold">
                    <span className="text-slate-900 dark:text-white">Total Balance</span>
                    <span className="font-mono font-black text-sm sm:text-base text-rose-600 dark:text-rose-400">
                      {formatCurrency(totalBalance)}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Optional Notes */}
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">
                Notes / Mandi Remarks
              </label>
              <input
                type="text"
                placeholder="Optional bill notes or remarks"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-xs text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>

            {/* Footer Buttons */}
            <div className="flex justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={onClose}
                className="rounded-lg border border-slate-300 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="rounded-lg bg-emerald-600 px-6 py-2 text-xs font-bold text-white shadow-md hover:bg-emerald-700"
              >
                {editItem ? 'Update Credit Sale' : 'Save Credit Sale'}
              </button>
            </div>
          </form>
        </div>
      </div>

      <AddCustomerModal
        isOpen={isAddCustomerOpen}
        onClose={() => setIsAddCustomerOpen(false)}
        onCustomerCreated={(newCust) => {
          handleCustomerChange(newCust.id);
          setIsAddCustomerOpen(false);
        }}
      />
    </>
  );
};
