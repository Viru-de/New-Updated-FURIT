import React, { useState } from 'react';
import { db } from '../../services/db';
import { getCustomerCrateStatement } from '../../services/accounting';
import { formatDate, toIsoDate, getTodayIso } from '../../utils/formatters';
import { DatePickerInput } from '../common/DatePickerInput';
import { CrateTransaction } from '../../types';
import { Box, Download, Printer, Plus, ArrowDownLeft, ArrowUpRight, Building2 } from 'lucide-react';
import { exportCrateStatement } from '../../utils/excelEngine';
import { BillShareButtons } from '../common/BillShareButtons';
import { triggerPrint } from '../../utils/pdfAndShareEngine';
import { CompanyContactsHeader } from '../common/CompanyContactsHeader';

interface CrateStatementViewProps {
  initialCustomerId?: string;
}

export const CrateStatementView: React.FC<CrateStatementViewProps> = ({
  initialCustomerId,
}) => {
  const customers = db.getCustomers();
  const crateTypes = db.getCrateTypes();
  const profiles = db.getCompanyProfiles();
  const defaultProfile = db.getDefaultProfile() || profiles[0];
  const [selectedProfileId, setSelectedProfileId] = useState<string>(
    defaultProfile?.id || profiles[0]?.id || ''
  );
  const currentProfile = profiles.find((p) => p.id === selectedProfileId) || defaultProfile || profiles[0];

  const [selectedCustomerId, setSelectedCustomerId] = useState(
    initialCustomerId || customers[0]?.id || ''
  );
  const [filterStartDate, setFilterStartDate] = useState('');
  const [filterEndDate, setFilterEndDate] = useState('');

  // Manual crate adjustment modal
  const [isAdjustmentModalOpen, setIsAdjustmentModalOpen] = useState(false);
  const [adjustType, setAdjustType] = useState<'Return' | 'Manual Adjustment'>('Return');
  const [adjustDate, setAdjustDate] = useState(getTodayIso());
  const [inQty, setInQty] = useState<number | ''>(0);
  const [outQty, setOutQty] = useState<number | ''>(0);
  const [adjustNotes, setAdjustNotes] = useState('');

  const activeCustomer = customers.find((c) => c.id === selectedCustomerId) || customers[0];

  const statement = selectedCustomerId
    ? getCustomerCrateStatement(selectedCustomerId, {
        startDate: filterStartDate ? toIsoDate(filterStartDate) : undefined,
        endDate: filterEndDate ? toIsoDate(filterEndDate) : undefined,
      })
    : { customer: undefined, entries: [], closingCrates: 0, crateWeightKg: 20, closingTotalKg: 0 };

  const handlePrint = () => {
    triggerPrint();
  };

  const handleExportCsv = () => {
    if (!activeCustomer) return;
    const headers = ['Date', 'Particulars', 'Reference', 'IN (Crates)', 'OUT (Crates)', 'Balance (Crates)', 'Weight (KG)', 'Total (KG)'];
    const rows = statement.entries.map((e) => [
      formatDate(e.date),
      `"${e.particulars}"`,
      e.referenceNo,
      e.inQuantity || '0',
      e.outQuantity || '0',
      e.balance,
      e.weightKg,
      e.totalKg,
    ]);
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Crate_Statement_${activeCustomer.name}_${getTodayIso()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleSaveAdjustment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomerId) return;

    const ct = crateTypes.find((c) => c.id === activeCustomer?.crateTypeId) || crateTypes[0];

    const manualTx: CrateTransaction = {
      id: `ct-${Date.now()}`,
      customerId: selectedCustomerId,
      customerName: activeCustomer ? activeCustomer.name : '',
      date: adjustDate,
      referenceType: adjustType,
      referenceNo: `CR-${Date.now().toString().slice(-4)}`,
      crateTypeId: ct?.id || 'ct1',
      crateName: ct?.name || 'Standard Crate',
      inQuantity: Number(inQty) || 0,
      outQuantity: Number(outQty) || 0,
      balanceQuantity: 0,
      weightKgPerCrate: ct?.defaultWeightKg || 20,
      totalKg: 0,
      notes: adjustNotes || 'Empty crates returned to Mandi yard',
      createdAt: new Date().toISOString(),
    };

    db.saveCrateTransaction(manualTx);
    setIsAdjustmentModalOpen(false);
    setInQty(0);
    setOutQty(0);
    setAdjustNotes('');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 no-print">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2">
            <Box className="h-5 w-5 text-sky-600" /> Crate Ledger & Statement
          </h2>
          <p className="text-xs text-slate-500">
            Independent quantity ledger: tracking empty and loaded crate movements in units & KG
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 no-print">
          <button
            type="button"
            onClick={() => setIsAdjustmentModalOpen(true)}
            className="flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
          >
            <Plus className="h-3.5 w-3.5 text-sky-600" /> Return / Adjust Crate
          </button>
          <button
            type="button"
            onClick={() => exportCrateStatement(activeCustomer?.id)}
            className="flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 cursor-pointer shadow-2xs"
          >
            <Download className="h-3.5 w-3.5 text-emerald-600" /> Export Excel
          </button>
          <button
            type="button"
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 cursor-pointer"
          >
            <Download className="h-3.5 w-3.5" /> CSV
          </button>
          <div className="flex items-center gap-1.5 no-print">
            <Building2 className="h-3.5 w-3.5 text-slate-400" />
            <select
              value={selectedProfileId}
              onChange={(e) => setSelectedProfileId(e.target.value)}
              className="rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-800 outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
              title="Select Billing Profile for Statement Header"
            >
              {profiles.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} {p.hindiName ? `(${p.hindiName})` : ''}
                </option>
              ))}
            </select>
          </div>
          <BillShareButtons
            elementId="crate-statement-print-area"
            filename={`Crate_Statement_${(activeCustomer?.name || 'Customer').replace(/\s+/g, '_')}`}
            customerMobile={activeCustomer?.mobile}
            title={`Customer Crate Statement - ${activeCustomer?.name || 'Customer'}`}
            summaryText={`Customer: ${activeCustomer?.name || 'Customer'}\nDate: ${formatDate(getTodayIso())}\nClosing Crates: ${statement.closingCrates} Crates\nTotal Weight: ${statement.closingTotalKg} KG`}
          />
          <button
            type="button"
            onClick={handlePrint}
            className="flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-slate-100 dark:text-slate-900 shadow-xs cursor-pointer"
          >
            <Printer className="h-3.5 w-3.5" /> Print Statement
          </button>
        </div>
      </div>

      {/* Customer Selector & Visual Formula Card */}
      <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-2xs dark:border-slate-800 dark:bg-slate-900 no-print">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          <div className="md:col-span-5">
            <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Select Customer
            </label>
            <select
              value={selectedCustomerId}
              onChange={(e) => setSelectedCustomerId(e.target.value)}
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-semibold text-slate-900 outline-none focus:border-sky-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
            >
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} {c.city ? `(${c.city})` : ''}
                </option>
              ))}
            </select>
          </div>

          <div className="md:col-span-7 bg-sky-50 border border-sky-100 rounded-lg p-3 dark:border-sky-900/50 dark:bg-sky-950/20">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <span className="block text-xs font-medium text-sky-800 dark:text-sky-300">
                  Current Customer Crate Balance
                </span>
                <span className="text-sm font-bold text-sky-950 dark:text-white">
                  {activeCustomer?.name}
                </span>
              </div>
              <div className="text-right">
                <div className="text-base sm:text-lg font-bold font-mono-numbers text-sky-900 dark:text-sky-200">
                  {statement.closingCrates} Crates × {statement.crateWeightKg} KG ={' '}
                  <span className="text-sky-700 dark:text-sky-300 underline decoration-sky-300">
                    {statement.closingTotalKg} KG
                  </span>
                </div>
                <div className="text-[11px] text-sky-600 dark:text-sky-400">
                  (Quantity formula: KG = Crate Quantity × Configured Crate Weight)
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Date Filter */}
        <div className="mt-3 flex flex-wrap items-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          <div className="w-40">
            <DatePickerInput
              label="From Date"
              value={filterStartDate}
              onChange={setFilterStartDate}
            />
          </div>
          <div className="w-40">
            <DatePickerInput
              label="To Date"
              value={filterEndDate}
              onChange={setFilterEndDate}
            />
          </div>
          {(filterStartDate || filterEndDate) && (
            <button
              type="button"
              onClick={() => {
                setFilterStartDate('');
                setFilterEndDate('');
              }}
              className="mb-1 rounded-lg border border-slate-200 px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300"
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {/* Crate Statement Table */}
      <div
        id="crate-statement-print-area"
        className="rounded-xl border border-slate-200 bg-white shadow-2xs dark:border-slate-800 dark:bg-slate-900 overflow-hidden print-bill-canvas"
      >
        {/* Printable Traditional Mandi Statement Header */}
        <div className="hidden print:block p-4 border-b border-black text-center mb-1">
          {currentProfile.shortCode && (
            <div className="font-bold text-xs tracking-widest uppercase text-slate-700 print:text-black">
              {currentProfile.shortCode}
            </div>
          )}
          <h1 className="text-lg sm:text-xl font-black uppercase tracking-wider">{currentProfile.name}</h1>
          {currentProfile.hindiName && (
            <div className="text-base sm:text-lg font-bold tracking-wide mt-0.5 font-devanagari text-slate-900 print:text-black">
              {currentProfile.hindiName}
            </div>
          )}
          <div className="text-[11px] text-slate-700 leading-snug mt-1">
            {currentProfile.address}
            {currentProfile.city ? `, ${currentProfile.city}` : ''}
            {currentProfile.state ? `, ${currentProfile.state}` : ''}
          </div>
          <CompanyContactsHeader profile={currentProfile} className="mt-0.5" />
          <div className="my-1.5 text-xs font-bold uppercase tracking-widest border-b border-t border-black py-0.5 inline-block">
            CUSTOMER CRATE STATEMENT
          </div>
          <div className="flex justify-between items-start text-xs mt-2 text-left border-t border-slate-300 pt-1.5">
            <div>
              <div className="font-bold text-sm">M/s. {activeCustomer?.name || 'Customer'}</div>
              {activeCustomer?.address && <div className="text-[11px]">{activeCustomer.address}</div>}
              {activeCustomer?.city && <div className="text-[11px]">{activeCustomer.city}</div>}
              {activeCustomer?.mobile && <div className="text-[11px]">Mob: {activeCustomer.mobile}</div>}
              {activeCustomer?.aadhaarNo && <div className="text-[10px]">Aadhaar: {activeCustomer.aadhaarNo}</div>}
            </div>
            <div className="text-right">
              <div>DATE: <strong>{formatDate(getTodayIso())}</strong></div>
              {(filterStartDate || filterEndDate) ? (
                <div className="text-[11px]">Period: {filterStartDate ? formatDate(filterStartDate) : 'Opening'} to {filterEndDate ? formatDate(filterEndDate) : 'Today'}</div>
              ) : (
                <div className="text-[11px]">Period: Complete Statement (All Transactions)</div>
              )}
              <div className="mt-1 font-bold">
                Closing Balance: <strong>{statement.closingCrates} Crates ({statement.closingTotalKg} KG)</strong>
              </div>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-600 dark:border-slate-800 dark:bg-slate-800/60 dark:text-slate-300">
                <th className="px-5 py-3.5 w-32">Date</th>
                <th className="px-5 py-3.5">Particulars / Transaction</th>
                <th className="px-5 py-3.5 text-center w-28">IN (Returned)</th>
                <th className="px-5 py-3.5 text-center w-28">OUT (Issued)</th>
                <th className="px-5 py-3.5 text-right w-36">Balance (Crates)</th>
                <th className="px-5 py-3.5 text-right w-36">Total KG</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {statement.entries.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-8 text-center text-xs text-slate-500">
                    No crate movements found for this customer.
                  </td>
                </tr>
              ) : (
                statement.entries.map((entry) => {
                  const isOb = entry.particulars === 'Opening Crate Balance';
                  return (
                    <tr
                      key={entry.id}
                      className={`hover:bg-slate-50/60 transition-colors dark:hover:bg-slate-800/40 ${
                        isOb ? 'bg-sky-50/20 font-medium' : ''
                      }`}
                    >
                      <td className="px-5 py-3 font-mono-numbers text-xs text-slate-700 dark:text-slate-300 whitespace-nowrap">
                        {formatDate(entry.date)}
                      </td>
                      <td className="px-5 py-3 text-slate-900 dark:text-white">
                        <div className="font-semibold text-xs sm:text-sm">{entry.particulars}</div>
                        <div className="text-[11px] text-slate-400">
                          {entry.crateName} ({entry.weightKg} KG/Crate)
                        </div>
                      </td>
                      {/* IN */}
                      <td className="px-5 py-3 text-center font-mono-numbers text-xs sm:text-sm font-semibold text-emerald-600 dark:text-emerald-400">
                        {entry.inQuantity > 0 ? (
                          <span className="inline-flex items-center gap-1">
                            <ArrowDownLeft className="h-3 w-3" /> {entry.inQuantity}
                          </span>
                        ) : (
                          '-'
                        )}
                      </td>
                      {/* OUT */}
                      <td className="px-5 py-3 text-center font-mono-numbers text-xs sm:text-sm font-semibold text-amber-600 dark:text-amber-400">
                        {entry.outQuantity > 0 ? (
                          <span className="inline-flex items-center gap-1">
                            <ArrowUpRight className="h-3 w-3" /> {entry.outQuantity}
                          </span>
                        ) : (
                          '-'
                        )}
                      </td>
                      {/* Balance (Crates) */}
                      <td className="px-5 py-3 text-right font-mono-numbers text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                        {entry.balance} {entry.balance === 1 ? 'Crate' : 'Crates'}
                      </td>
                      {/* Total KG */}
                      <td className="px-5 py-3 text-right font-mono-numbers text-xs sm:text-sm font-bold text-sky-700 dark:text-sky-300">
                        {entry.totalKg} KG
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
            <tfoot>
              <tr className="border-t-2 border-slate-300 bg-slate-50/90 font-bold dark:border-slate-700 dark:bg-slate-800/80">
                <td colSpan={4} className="px-5 py-3.5 text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300">
                  Closing Crate Balance
                </td>
                <td className="px-5 py-3.5 text-right font-mono-numbers text-base text-slate-900 dark:text-white">
                  {statement.closingCrates} Crates
                </td>
                <td className="px-5 py-3.5 text-right font-mono-numbers text-base text-sky-700 dark:text-sky-300">
                  {statement.closingTotalKg} KG
                </td>
              </tr>
            </tfoot>
          </table>
        </div>

        {/* Bottom Banner */}
        <div className="flex flex-col sm:flex-row items-center justify-between border-t border-slate-200 bg-sky-50/60 px-6 py-4 dark:border-slate-800 dark:bg-sky-950/20">
          <div className="text-xs text-sky-800 dark:text-sky-300">
            Total Crates held by <strong>{activeCustomer?.name}</strong>: {statement.closingCrates}
          </div>
          <div className="flex items-center gap-2 mt-2 sm:mt-0">
            <span className="text-xs font-semibold text-slate-600 dark:text-slate-400">
              Total Weight Equivalent:
            </span>
            <span className="font-mono-numbers text-lg font-extrabold text-sky-800 dark:text-sky-200">
              {statement.closingTotalKg} KG
            </span>
          </div>
        </div>

        {/* Software attribution & Signatory */}
        <div className="p-3 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 print:border-black flex justify-between items-center text-xs">
          <div className="text-[8px] sm:text-[8.5px] text-left text-slate-500 print:text-black font-mono">
            Software Developed by: {defaultProfile.softwareDevelopedBy || 'Klyia Technology'}
          </div>
          <div className="hidden print:block text-right font-bold uppercase text-[11px]">
            FOR, {defaultProfile.signatureTitle || defaultProfile.name}
          </div>
        </div>
      </div>

      {/* Manual Crate Adjustment Modal */}
      {isAdjustmentModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-xl border border-slate-200 bg-white shadow-xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4 dark:border-slate-800">
              <h3 className="text-base font-semibold text-slate-900 dark:text-white">
                Record Crate Return or Adjustment
              </h3>
              <button
                type="button"
                onClick={() => setIsAdjustmentModalOpen(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveAdjustment} className="space-y-4 p-5">
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Customer
                </label>
                <div className="text-sm font-bold text-slate-900 dark:text-white">
                  {activeCustomer?.name}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <DatePickerInput
                  label="Date"
                  required
                  value={adjustDate}
                  onChange={setAdjustDate}
                />
                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Type
                  </label>
                  <select
                    value={adjustType}
                    onChange={(e) => setAdjustType(e.target.value as any)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 outline-none focus:border-sky-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    <option value="Return">Empty Crate Return (IN)</option>
                    <option value="Manual Adjustment">Manual Issue (OUT)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Crate IN (Returned)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={inQty}
                    onChange={(e) => setInQty(e.target.value ? Number(e.target.value) : '')}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono-numbers text-slate-900 outline-none focus:border-sky-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Crate OUT (Issued)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={outQty}
                    onChange={(e) => setOutQty(e.target.value ? Number(e.target.value) : '')}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono-numbers text-slate-900 outline-none focus:border-sky-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Notes
                </label>
                <input
                  type="text"
                  placeholder="e.g. Returned 10 plastic crates via tempo"
                  value={adjustNotes}
                  onChange={(e) => setAdjustNotes(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 outline-none focus:border-sky-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAdjustmentModalOpen(false)}
                  className="rounded-lg border border-slate-300 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-sky-600 px-4 py-2 text-xs font-semibold text-white hover:bg-sky-700"
                >
                  Save Crate Entry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
