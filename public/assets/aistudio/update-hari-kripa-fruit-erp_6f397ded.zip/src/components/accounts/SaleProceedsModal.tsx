import React, { useState, useEffect } from 'react';
import { ExpenseItem, Fruit, SaleProceeds } from '../../types';
import { db } from '../../services/db';
import { formatCurrency, formatSequence, getTodayIso } from '../../utils/formatters';
import { getFruitEffectivePrice } from '../../utils/fruitUtils';
import { DatePickerInput } from '../common/DatePickerInput';
import { AddFruitModal } from '../modals/AddFruitModal';
import { X, Plus, Trash2, Calculator, Info } from 'lucide-react';

interface SaleProceedsModalProps {
  isOpen: boolean;
  onClose: () => void;
  editItem?: SaleProceeds | null;
  onSaved: (item: SaleProceeds) => void;
}

export const SaleProceedsModal: React.FC<SaleProceedsModalProps> = ({
  isOpen,
  onClose,
  editItem,
  onSaved,
}) => {
  const fruits = db.getFruits();
  const vendors = db.getVendors();
  const customers = db.getCustomers();
  const units = db.getUnits();

  const [date, setDate] = useState(getTodayIso());
  const [challanDate, setChallanDate] = useState(getTodayIso());
  const [billNumber, setBillNumber] = useState('');
  const [selectedFruitId, setSelectedFruitId] = useState('');
  const [quantity, setQuantity] = useState<number | ''>(14);
  const [unit, setUnit] = useState('Crate');
  const [rate, setRate] = useState<number | ''>(414);
  
  // Amount is manually editable! Default calculation can be provided, but user can freely change it.
  const [amount, setAmount] = useState<number | ''>(4186);
  const [vendorId, setVendorId] = useState('');
  const [customerId, setCustomerId] = useState('');
  const [notes, setNotes] = useState('');

  // Expenses: Freight, Hamali, Postage, etc.
  const [expenses, setExpenses] = useState<ExpenseItem[]>([
    { id: 'exp-1', name: 'Freight', amount: 100 },
    { id: 'exp-2', name: 'Hamali', amount: 10 },
    { id: 'exp-3', name: 'Postage', amount: 6 },
  ]);

  const [isAddFruitOpen, setIsAddFruitOpen] = useState(false);

  useEffect(() => {
    if (editItem) {
      setDate(editItem.date);
      setChallanDate(editItem.challanDate || editItem.date);
      setBillNumber(editItem.billNumber || '');
      const firstItem = editItem.items?.[0];
      setSelectedFruitId(firstItem?.fruitId || '');
      setQuantity(editItem.quantity);
      setUnit(editItem.unit || 'Crate');
      setRate(editItem.rate);
      setAmount(editItem.amount);
      setExpenses(editItem.expenses || []);
      setVendorId(editItem.vendorId || '');
      setCustomerId(editItem.customerId || '');
      setNotes(editItem.notes || '');
    } else {
      // Default new entry
      setDate(getTodayIso());
      setChallanDate(getTodayIso());
      setBillNumber('');
      const defaultFruit = fruits.find(f => f.name.toLowerCase().includes('strawberry')) || fruits[0];
      if (defaultFruit) {
        setSelectedFruitId(defaultFruit.id);
        setUnit(defaultFruit.defaultUnit || 'Crate');
        setRate(getFruitEffectivePrice(defaultFruit));
      }
      setQuantity(14);
      setAmount(4186); // user scenario default
      setExpenses([
        { id: 'exp-1', name: 'Freight', amount: 100 },
        { id: 'exp-2', name: 'Hamali', amount: 10 },
        { id: 'exp-3', name: 'Postage', amount: 6 },
      ]);
      setVendorId('');
      setCustomerId('');
      setNotes('');
    }
  }, [editItem, isOpen]);

  if (!isOpen) return null;

  const currentFruit = fruits.find((f) => f.id === selectedFruitId);

  const handleFruitSelect = (id: string) => {
    setSelectedFruitId(id);
    const fruit = fruits.find((f) => f.id === id);
    if (fruit) {
      setUnit(fruit.defaultUnit || 'Crate');
      setRate(getFruitEffectivePrice(fruit));
    }
  };

  const calculateAutoAmount = () => {
    const q = Number(quantity) || 0;
    const r = Number(rate) || 0;
    setAmount(q * r);
  };

  const handleExpenseChange = (index: number, field: 'name' | 'amount', val: any) => {
    const updated = [...expenses];
    if (field === 'amount') {
      updated[index].amount = Number(val) || 0;
    } else {
      updated[index].name = val;
    }
    setExpenses(updated);
  };

  const handleAddExpense = () => {
    setExpenses([
      ...expenses,
      { id: `exp-${Date.now()}`, name: 'Other', amount: 0 },
    ]);
  };

  const handleRemoveExpense = (index: number) => {
    setExpenses(expenses.filter((_, i) => i !== index));
  };

  // Calculations
  const numericAmount = Number(amount) || 0;
  const totalExpense = expenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
  const netAmount = numericAmount - totalExpense;
  const difference = netAmount - numericAmount; // = -totalExpense

  const handleFruitCreated = (newFruit: Fruit) => {
    setSelectedFruitId(newFruit.id);
    setUnit(newFruit.defaultUnit || 'Crate');
    setRate(getFruitEffectivePrice(newFruit));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFruitId && fruits.length === 0) return;

    const seq = editItem ? editItem.sequenceNumber : db.getNextSaleProceedsNumber();
    const proceedsNo = editItem
      ? editItem.proceedsNo
      : `Sale Proceeds No. ${formatSequence(seq, 3)}`;

    const selectedVendor = vendors.find((v) => v.id === vendorId);
    const selectedCustomer = customers.find((c) => c.id === customerId);
    const fruitName = currentFruit ? currentFruit.name : 'Fruit';

    const saleRecord: SaleProceeds = {
      id: editItem ? editItem.id : `sp-${Date.now()}`,
      proceedsNo,
      sequenceNumber: seq,
      date,
      challanDate,
      billNumber: editItem ? editItem.billNumber : undefined,
      items: [
        {
          id: `spi-${Date.now()}`,
          fruitId: selectedFruitId,
          fruitName,
          quantity: Number(quantity) || 0,
          unit,
          rate: Number(rate) || 0,
          amount: numericAmount,
        },
      ],
      quantity: Number(quantity) || 0,
      unit,
      rate: Number(rate) || 0,
      amount: numericAmount,
      expenses,
      totalExpense,
      netAmount,
      difference,
      vendorId: vendorId || undefined,
      vendorName: selectedVendor?.name,
      customerId: customerId || undefined,
      customerName: selectedCustomer?.name,
      notes: notes.trim() || undefined,
      createdAt: editItem ? editItem.createdAt : new Date().toISOString(),
    };

    db.saveSaleProceeds(saleRecord);
    onSaved(saleRecord);
    onClose();
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
        <div className="w-full max-w-2xl rounded-xl border border-slate-200 bg-white shadow-xl dark:border-slate-800 dark:bg-slate-900 max-h-[92vh] overflow-y-auto min-w-0 mx-2 sm:mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-slate-100 px-4 sm:px-6 py-4 dark:border-slate-800">
            <div>
              <h3 className="text-base font-semibold text-slate-900 dark:text-white">
                {editItem ? `Edit ${editItem.proceedsNo}` : 'New Sale Proceeds Entry'}
              </h3>
              <p className="text-xs text-slate-500">
                Direct wholesale mandi consignment sale & proceeds calculation
              </p>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-5 p-4 sm:p-6">
            {/* Row 1: Dates */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <DatePickerInput
                label="Date"
                required
                value={date}
                onChange={setDate}
              />
              <DatePickerInput
                label="Challan Date"
                value={challanDate}
                onChange={setChallanDate}
              />
            </div>

            {/* Product Section */}
            <div className="rounded-lg border border-slate-200 bg-slate-50/60 p-4 dark:border-slate-800 dark:bg-slate-800/30">
              <div className="mb-3 flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                  Fruit / Consignment Product
                </span>
                <button
                  type="button"
                  onClick={() => setIsAddFruitOpen(true)}
                  className="flex items-center gap-1 text-xs font-semibold text-emerald-600 hover:text-emerald-700 dark:text-emerald-400"
                >
                  <Plus className="h-3.5 w-3.5" /> + Add New Fruit
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
                <div className="sm:col-span-5">
                  <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">
                    Product *
                  </label>
                  <select
                    required
                    value={selectedFruitId}
                    onChange={(e) => handleFruitSelect(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    <option value="">-- Select Fruit --</option>
                    {fruits.map((f) => (
                      <option key={f.id} value={f.id}>
                        {f.name} ({f.category})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">
                    Quantity *
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    step="any"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value ? Number(e.target.value) : '')}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-mono-numbers text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">
                    Unit
                  </label>
                  <select
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 bg-white px-2 py-2 text-sm text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    {units.map((u) => (
                      <option key={u.id} value={u.symbol}>
                        {u.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="sm:col-span-3">
                  <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">
                    Rate (₹) *
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    step="any"
                    value={rate}
                    onChange={(e) => setRate(e.target.value ? Number(e.target.value) : '')}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-mono-numbers text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              {/* Amount - Manual editable requirement! */}
              <div className="mt-3 rounded-lg border border-amber-200 bg-amber-50/50 p-3 dark:border-amber-900/40 dark:bg-amber-950/20">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <label className="block text-xs font-bold text-slate-800 dark:text-slate-200">
                      Amount (₹) — Manually Editable
                    </label>
                    <span className="text-[11px] text-slate-500">
                      Quantity {quantity || 0} × Rate ₹{rate || 0} = {formatCurrency((Number(quantity) || 0) * (Number(rate) || 0))} (App does NOT force formula)
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={calculateAutoAmount}
                      title="Set to Qty × Rate"
                      className="flex items-center gap-1 rounded border border-slate-300 bg-white px-2 py-1 text-xs text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
                    >
                      <Calculator className="h-3 w-3" /> Auto (Qty × Rate)
                    </button>
                    <input
                      type="number"
                      step="any"
                      required
                      placeholder="e.g. 4186"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value ? Number(e.target.value) : '')}
                      className="w-36 rounded-lg border-2 border-emerald-500 bg-white px-3 py-1.5 text-right font-mono-numbers text-base font-bold text-slate-900 outline-none dark:bg-slate-900 dark:text-white"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Expenses Section */}
            <div className="rounded-lg border border-slate-200 p-4 dark:border-slate-800">
              <div className="mb-2 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                    Consignment Expenses
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    Freight, Hamali, Postage and custom deductions
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleAddExpense}
                  className="flex items-center gap-1 text-xs font-semibold text-emerald-600 hover:text-emerald-700 dark:text-emerald-400"
                >
                  <Plus className="h-3.5 w-3.5" /> + Add Expense
                </button>
              </div>

              <div className="space-y-2">
                {expenses.map((exp, idx) => (
                  <div key={exp.id || idx} className="flex items-center gap-2">
                    <input
                      type="text"
                      value={exp.name}
                      placeholder="Expense Name (e.g. Freight, Hamali)"
                      onChange={(e) => handleExpenseChange(idx, 'name', e.target.value)}
                      className="flex-1 rounded-lg border border-slate-300 px-3 py-1.5 text-sm text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                    />
                    <div className="relative w-36">
                      <span className="absolute left-3 top-2 text-xs text-slate-400">₹</span>
                      <input
                        type="number"
                        min="0"
                        step="any"
                        value={exp.amount === 0 ? '' : exp.amount}
                        placeholder="0.00"
                        onChange={(e) => handleExpenseChange(idx, 'amount', e.target.value)}
                        className="w-full rounded-lg border border-slate-300 pl-6 pr-3 py-1.5 text-right font-mono-numbers text-sm text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                      />
                    </div>
                    {expenses.length > 1 && (
                      <button
                        type="button"
                        onClick={() => handleRemoveExpense(idx)}
                        className="p-1.5 text-slate-400 hover:text-rose-500"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Calculations Summary Box */}
            <div className="rounded-lg border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-800/40">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
                <div className="p-2 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <span className="block text-[11px] font-medium text-slate-500">Amount</span>
                  <span className="text-base font-bold font-mono-numbers text-slate-900 dark:text-white">
                    {formatCurrency(numericAmount)}
                  </span>
                </div>
                <div className="p-2 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <span className="block text-[11px] font-medium text-slate-500">Total Expense</span>
                  <span className="text-base font-bold font-mono-numbers text-rose-600 dark:text-rose-400">
                    {formatCurrency(totalExpense)}
                  </span>
                </div>
                <div className="p-2 rounded bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900">
                  <span className="block text-[11px] font-medium text-emerald-700 dark:text-emerald-300">Net Credit</span>
                  <span className="text-base font-bold font-mono-numbers text-emerald-700 dark:text-emerald-300">
                    {formatCurrency(netAmount)}
                  </span>
                </div>
                <div className="p-2 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <span className="block text-[11px] font-medium text-slate-500">Difference</span>
                  <span className="text-base font-bold font-mono-numbers text-slate-600 dark:text-slate-400">
                    {formatCurrency(difference)}
                  </span>
                </div>
              </div>
            </div>

            {/* Additional info */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Wholesale Vendor / Consignor
                </label>
                <select
                  value={vendorId}
                  onChange={(e) => setVendorId(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                >
                  <option value="">-- No Vendor Selected --</option>
                  {vendors.map((v) => (
                    <option key={v.id} value={v.id}>
                      {v.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Customer (Optional)
                </label>
                <select
                  value={customerId}
                  onChange={(e) => setCustomerId(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                >
                  <option value="">-- No Customer Selected --</option>
                  {customers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} {c.city ? `(${c.city})` : ''}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Notes / Consignment Remarks
                </label>
                <input
                  type="text"
                  placeholder="e.g. Hill harvest quality, vehicle no."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>
            </div>

            {/* Actions */}
            <div className="flex justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={onClose}
                className="rounded-lg border border-slate-300 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="rounded-lg bg-emerald-600 px-5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-emerald-700"
              >
                {editItem ? 'Update Sale Proceeds' : 'Save Sale Proceeds'}
              </button>
            </div>
          </form>
        </div>
      </div>

      <AddFruitModal
        isOpen={isAddFruitOpen}
        onClose={() => setIsAddFruitOpen(false)}
        onFruitCreated={handleFruitCreated}
      />
    </>
  );
};
