import React, { useState, useEffect, useMemo } from 'react';
import { CashSale, CashSaleItem, Customer, ExpenseItem, Fruit } from '../../types';
import { db } from '../../services/db';
import { formatCurrency, formatSequence, getTodayIso } from '../../utils/formatters';
import {
  isCrateUnit,
  getAvailableCrateSizes,
  getDefaultCrateSizeForFruit,
} from '../../utils/crateUtils';
import { getFruitEffectivePrice } from '../../utils/fruitUtils';
import {
  calculateLineKg,
  calculateLineAmount,
  calculateWholesaleItemAmount,
  calculateSaleCrateSummary,
  formatQtyWithUnit,
} from '../../utils/billingCalculations';
import { DatePickerInput } from '../common/DatePickerInput';
import { AddFruitModal } from '../modals/AddFruitModal';
import { AddCustomerModal } from '../modals/AddCustomerModal';
import { BillTableCanvas } from '../common/BillTableCanvas';
import { CashSalePrintModal } from '../print/CashSalePrintModal';
import {
  X,
  Plus,
  Trash2,
  Box,
  UserPlus,
  Info,
  Printer,
  Eye,
  Edit3,
  CheckCircle2,
  Banknote,
} from 'lucide-react';

const COMMON_UNITS = ['Crate', 'Box', 'Peti', 'DABBA', 'Packet', 'Bag', 'KG', 'Nag', 'Piece'];

interface CashSaleModalProps {
  isOpen: boolean;
  onClose: () => void;
  editItem?: CashSale | null;
  onSaved: (item: CashSale) => void;
  preselectedCustomerId?: string;
}

export const CashSaleModal: React.FC<CashSaleModalProps> = ({
  isOpen,
  onClose,
  editItem,
  onSaved,
  preselectedCustomerId,
}) => {
  const customers = db.getCustomers();
  const fruits = db.getFruits();
  const crateTypes = db.getCrateTypes();
  const units = db.getUnits();
  const availableCrateSizes = useMemo(() => getAvailableCrateSizes(), [crateTypes]);

  const [activeTab, setActiveTab] = useState<'form' | 'preview'>('form');
  const [customerId, setCustomerId] = useState('');
  const [date, setDate] = useState(getTodayIso());
  const [paymentMode, setPaymentMode] = useState<CashSale['paymentMode']>('Cash');
  const [items, setItems] = useState<CashSaleItem[]>([]);
  const [expenses, setExpenses] = useState<ExpenseItem[]>([
    { id: 'cse-1', name: 'Hamali', amount: 50 },
  ]);

  const allUnitOptions = useMemo(() => {
    const set = new Set<string>();
    COMMON_UNITS.forEach((u) => set.add(u));
    units.forEach((u) => set.add(u.symbol));
    items.forEach((it) => {
      if (it.unit) set.add(it.unit);
    });
    return Array.from(set);
  }, [units, items]);

  // Crate fields
  const [crateTypeId, setCrateTypeId] = useState(crateTypes[0]?.id || '');
  const [crateIn, setCrateIn] = useState<number | ''>(0);
  const [crateOut, setCrateOut] = useState<number | ''>(1);

  // Manual final amount adjustment option
  const [isManualAmountOverridden, setIsManualAmountOverridden] = useState(false);
  const [manualAmount, setManualAmount] = useState<number | ''>('');
  const [notes, setNotes] = useState('');

  const [isAddFruitOpen, setIsAddFruitOpen] = useState(false);
  const [isAddCustomerOpen, setIsAddCustomerOpen] = useState(false);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  useEffect(() => {
    if (editItem) {
      setCustomerId(editItem.customerId || '');
      setDate(editItem.date);
      setPaymentMode(editItem.paymentMode || 'Cash');
      setItems(editItem.items || []);
      setExpenses(editItem.expenses || []);
      setCrateTypeId(editItem.crateTypeId || crateTypes[0]?.id || '');
      setCrateIn(editItem.crateIn ?? '');
      setCrateOut(editItem.crateOut ?? '');
      if (editItem.manualAdjustedAmount !== undefined) {
        setIsManualAmountOverridden(true);
        setManualAmount(editItem.manualAdjustedAmount);
      } else {
        setIsManualAmountOverridden(false);
        setManualAmount('');
      }
      setNotes(editItem.notes || '');
    } else {
      setCustomerId(preselectedCustomerId || '');
      setDate(getTodayIso());
      setPaymentMode('Cash');

      const defFruit = fruits[0];
      const defRate = getFruitEffectivePrice(defFruit);
      const isCrate = isCrateUnit(defFruit?.defaultUnit);
      const defUnit = defFruit?.defaultUnit || 'Crate';
      const defKg = 0; // Set Kg to 0 by default for new item rows
      const defQty = 1;
      const defAmount = calculateWholesaleItemAmount(defQty, defUnit, defKg, defRate);

      setItems([
        {
          id: `casi-${Date.now()}-1`,
          fruitId: defFruit?.id || '',
          fruitName: defFruit?.name || 'Fruit',
          quantity: defQty,
          unit: defUnit,
          kg: defKg,
          crateSize: isCrate ? getDefaultCrateSizeForFruit(defFruit) : undefined,
          rate: defRate,
          amount: defAmount,
        },
      ]);

      setExpenses([{ id: 'cse-cash-1', name: 'Hamali', amount: 50 }]);
      setCrateTypeId(crateTypes[0]?.id || '');
      setCrateIn(0);
      setCrateOut(isCrate ? 1 : 0);
      setIsManualAmountOverridden(false);
      setManualAmount('');
      setNotes('');
    }
  }, [editItem, isOpen, preselectedCustomerId]);

  if (!isOpen) return null;

  const selectedCustomer = customers.find((c) => c.id === customerId);
  const selectedCrateType = crateTypes.find((ct) => ct.id === crateTypeId) || crateTypes[0];
  const crateWeight = selectedCrateType?.defaultWeightKg || 20;

  // Item manipulations
  const handleItemChange = (index: number, field: keyof CashSaleItem, val: any) => {
    const updated = [...items];
    const current = { ...updated[index] };

    if (field === 'fruitId') {
      const fr = fruits.find((f) => f.id === val);
      if (fr) {
        current.fruitId = fr.id;
        current.fruitName = fr.name;
        const prevWasCrate = isCrateUnit(current.unit);
        current.unit = fr.defaultUnit || 'Crate';
        current.rate = getFruitEffectivePrice(fr);
        if (isCrateUnit(current.unit)) {
          current.crateSize = getDefaultCrateSizeForFruit(fr);
        } else {
          current.crateSize = undefined;
          if (prevWasCrate) {
            current.kg = 0;
          }
        }
      }
    } else if (field === 'fruitName') {
      current.fruitName = val;
    } else if (field === 'unit') {
      const prevWasCrate = isCrateUnit(current.unit);
      const nextUnit = String(val).trim();
      current.unit = nextUnit;
      if (isCrateUnit(nextUnit)) {
        const fr = fruits.find((f) => f.id === current.fruitId);
        current.crateSize = getDefaultCrateSizeForFruit(fr);
      } else {
        current.crateSize = undefined;
        // Changing the unit from Crate to Box, Peti, DABBA, or another unit sets Kg to 0 by default
        if (prevWasCrate && !isCrateUnit(nextUnit)) {
          current.kg = 0;
        }
      }
    } else if (field === 'quantity') {
      const q = val === '' ? 0 : Number(val);
      current.quantity = isNaN(q) ? 0 : q;
    } else if (field === 'kg') {
      const k = val === '' ? 0 : Number(val);
      current.kg = isNaN(k) ? 0 : k;
    } else if (field === 'rate') {
      const r = val === '' ? 0 : Number(val);
      current.rate = isNaN(r) ? 0 : r;
    } else if (field === 'crateSize') {
      current.crateSize = val;
    }

    // Recalculate the amount instantly whenever Qty, Unit, Kg, or Rate changes
    current.amount = calculateWholesaleItemAmount(
      current.quantity,
      current.unit,
      current.kg,
      current.rate
    );

    updated[index] = current;
    setItems(updated);
  };

  const handleAddItem = () => {
    const firstFruit = fruits[0];
    const unit = firstFruit?.defaultUnit || 'Crate';
    const isCrate = isCrateUnit(unit);
    const crateSize = isCrate ? getDefaultCrateSizeForFruit(firstFruit) : undefined;
    const firstRate = getFruitEffectivePrice(firstFruit);
    const firstKg = 0; // Default Kg to 0 for new item rows
    const firstAmount = calculateWholesaleItemAmount(1, unit, firstKg, firstRate);

    setItems([
      ...items,
      {
        id: `casi-${Date.now()}`,
        fruitId: firstFruit?.id || '',
        fruitName: firstFruit?.name || 'Fruit',
        quantity: 1,
        unit: unit,
        kg: firstKg,
        crateSize: crateSize,
        rate: firstRate,
        amount: firstAmount,
      },
    ]);
  };

  const handleRemoveItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const handleExpenseChange = (index: number, field: 'name' | 'amount', val: any) => {
    const updated = [...expenses];
    if (field === 'amount') {
      updated[index].amount = Number(val) || 0;
    } else {
      updated[index].name = val;
    }
    setExpenses(updated);
  };

  const handleAddExpense = () => {
    setExpenses([
      ...expenses,
      { id: `cse-${Date.now()}`, name: 'Other', amount: 0 },
    ]);
  };

  const handleRemoveExpense = (index: number) => {
    setExpenses(expenses.filter((_, i) => i !== index));
  };

  // Calculations
  const productTotal = items.reduce((sum, it) => sum + (Number(it.amount) || 0), 0);
  const expenseTotal = expenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
  const totalAmount = productTotal + expenseTotal;
  const finalAmount = isManualAmountOverridden && manualAmount !== ''
    ? Number(manualAmount)
    : totalAmount;

  // Crate breakdown
  const crateSummary = calculateSaleCrateSummary(items, Number(crateOut) || 0, Number(crateIn) || 0, crateWeight);

  const seqNumber = editItem ? editItem.sequenceNumber : db.getNextCashSaleNumber();
  const cashSaleNo = editItem ? editItem.cashSaleNo : `Cash Sale No. ${formatSequence(seqNumber, 3)}`;

  const currentSaleRecord: CashSale = {
    id: editItem ? editItem.id : `cash-s-${Date.now()}`,
    cashSaleNo,
    sequenceNumber: seqNumber,
    customerId: customerId || undefined,
    customerName: selectedCustomer ? selectedCustomer.name : '',
    date,
    items: items.map((it) => ({
      ...it,
      amount: calculateWholesaleItemAmount(it.quantity, it.unit, it.kg, it.rate),
    })),
    crateTypeId,
    crateName: selectedCrateType?.name || 'Standard Crate',
    crateIn: Number(crateIn) || 0,
    crateOut: Number(crateOut) || 0,
    crateWeightKg: crateWeight,
    expenses,
    productTotal,
    expenseTotal,
    totalAmount,
    manualAdjustedAmount: isManualAmountOverridden ? Number(manualAmount) : undefined,
    finalAmount,
    paymentMode,
    paymentStatus: 'Paid',
    receivedAmount: finalAmount,
    notes: notes.trim() || undefined,
    createdAt: editItem ? editItem.createdAt : new Date().toISOString(),
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) return;

    db.saveCashSale(currentSaleRecord);
    onSaved(currentSaleRecord);
    onClose();
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
        <div className="w-full max-w-4xl rounded-xl border border-slate-200 bg-white shadow-xl dark:border-slate-800 dark:bg-slate-900 max-h-[92vh] overflow-y-auto min-w-0 mx-2 sm:mx-auto">
          {/* Header & Tabs */}
          <div className="flex flex-wrap items-center justify-between border-b border-slate-100 px-4 sm:px-6 py-3.5 dark:border-slate-800 gap-3">
            <div className="flex items-center gap-2">
              <Banknote className="h-5 w-5 text-emerald-600" />
              <div>
                <h3 className="text-base font-semibold text-slate-900 dark:text-white">
                  {editItem ? `Edit ${editItem.cashSaleNo}` : 'New Wholesale Cash Sale'}
                </h3>
                <p className="text-xs text-slate-500">
                  Paid wholesale bill with exact item Qty/KG & Balance Crate calculation
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {/* Tab Switcher: Form vs Live Preview */}
              <div className="flex items-center rounded-lg border border-slate-200 p-0.5 bg-slate-100 dark:border-slate-800 dark:bg-slate-800 text-xs">
                <button
                  type="button"
                  onClick={() => setActiveTab('form')}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded-md font-semibold transition-all ${
                    activeTab === 'form'
                      ? 'bg-white text-slate-900 shadow-2xs dark:bg-slate-900 dark:text-white'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  <Edit3 className="h-3.5 w-3.5" /> Form Entry
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('preview')}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded-md font-semibold transition-all ${
                    activeTab === 'preview'
                      ? 'bg-white text-slate-900 shadow-2xs dark:bg-slate-900 dark:text-white'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  <Eye className="h-3.5 w-3.5" /> Live Bill Preview
                </button>
              </div>

              <button
                type="button"
                onClick={onClose}
                className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          </div>

          {activeTab === 'preview' ? (
            <div className="p-4 sm:p-6 bg-slate-100 dark:bg-slate-950 flex flex-col items-center">
              <div className="mb-4 flex items-center justify-between w-full max-w-xl">
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  Live synchronized bill preview matching printed bill
                </div>
                <button
                  type="button"
                  onClick={() => setIsPrintModalOpen(true)}
                  className="flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700 shadow-xs cursor-pointer"
                >
                  <Printer className="h-3.5 w-3.5" /> Print Bill / PDF
                </button>
              </div>
              <BillTableCanvas
                saleType="CASH SALE"
                billNumber={cashSaleNo}
                date={date}
                customerName={selectedCustomer?.name || ''}
                customerAddress={selectedCustomer?.address}
                customerMobile={selectedCustomer?.mobile}
                customerAadhaarNo={selectedCustomer?.aadhaarNo || selectedCustomer?.gstin}
                items={items}
                expenses={expenses}
                productTotal={productTotal}
                expenseTotal={expenseTotal}
                finalAmount={finalAmount}
                paymentMode={paymentMode}
                crateOut={Number(crateOut) || 0}
                crateIn={Number(crateIn) || 0}
                crateWeightKg={crateWeight}
                isLivePreview={true}
              />
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-5 p-4 sm:p-6">
              {/* Customer, Date & Payment Mode */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
                <div>
                  <div className="mb-1 flex items-center justify-between">
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                      Customer (Optional)
                    </label>
                    <button
                      type="button"
                      onClick={() => setIsAddCustomerOpen(true)}
                      className="flex items-center gap-1 text-[11px] font-medium text-emerald-600 hover:text-emerald-700"
                    >
                      <UserPlus className="h-3 w-3" /> + Add
                    </button>
                  </div>
                  <select
                    value={customerId}
                    onChange={(e) => setCustomerId(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    <option value="">-- No Customer (Blank / Optional) --</option>
                    {customers.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} {c.mobile ? `(${c.mobile})` : ''} - {c.city || 'Mandi'}
                      </option>
                    ))}
                  </select>
                </div>

                <DatePickerInput
                  label="Sale Date"
                  required
                  value={date}
                  onChange={setDate}
                />

                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Payment Mode (Paid) *
                  </label>
                  <select
                    value={paymentMode}
                    onChange={(e) => setPaymentMode(e.target.value as any)}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white font-medium"
                  >
                    <option value="Cash">Cash (Immediate Settlement)</option>
                    <option value="UPI">UPI / QR Code</option>
                    <option value="Bank Transfer">Bank Transfer / NEFT</option>
                  </select>
                </div>
              </div>

              {/* Items Table with exact headings: No. | Item Name | Qty | KG | Rate | Amount */}
              <div className="rounded-lg border border-slate-200 p-3 sm:p-4 dark:border-slate-800">
                <div className="mb-3 flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                      Sale Items
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      Exact column layout: No., Item Name, Qty, KG, Rate, Amount
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setIsAddFruitOpen(true)}
                      className="text-xs font-semibold text-emerald-600 hover:text-emerald-700"
                    >
                      + New Fruit
                    </button>
                    <button
                      type="button"
                      onClick={handleAddItem}
                      className="flex items-center gap-1 rounded bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-700 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300"
                    >
                      <Plus className="h-3.5 w-3.5" /> + Add Row
                    </button>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 text-[11px] font-bold uppercase tracking-wider text-slate-600 dark:border-slate-800 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/40">
                        <th className="py-2 px-2 text-center w-10">No.</th>
                        <th className="py-2 px-2 min-w-[160px]">Item Name *</th>
                        <th className="py-2 px-2 w-28 text-right">Qty *</th>
                        <th className="py-2 px-2 w-20 text-center">Unit</th>
                        <th className="py-2 px-2 w-24 text-center">Crate Size</th>
                        <th className="py-2 px-2 w-20 text-right">KG</th>
                        <th className="py-2 px-2 w-24 text-right">Rate (₹)</th>
                        <th className="py-2 px-2 w-24 text-right">Amount (₹)</th>
                        <th className="py-2 px-1 w-8 text-center"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {items.map((it, idx) => {
                        const lineKg = calculateLineKg(it, fruits);
                        return (
                          <tr key={it.id || idx}>
                            <td className="py-2 px-2 text-center font-mono font-bold text-slate-400">
                              {idx + 1}
                            </td>

                            {/* Item Name */}
                            <td className="py-2 px-2">
                              <select
                                value={it.fruitId}
                                onChange={(e) => handleItemChange(idx, 'fruitId', e.target.value)}
                                className="w-full rounded-lg border border-slate-300 bg-white px-2 py-1.5 text-xs text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                              >
                                <option value="">Select Fruit</option>
                                {fruits.map((f) => (
                                  <option key={f.id} value={f.id}>
                                    {f.name}
                                  </option>
                                ))}
                              </select>
                            </td>

                            {/* Qty */}
                            <td className="py-2 px-2 text-right">
                              <input
                                type="number"
                                min="0.01"
                                step="any"
                                placeholder="Qty"
                                value={it.quantity === 0 ? '' : it.quantity}
                                onChange={(e) => handleItemChange(idx, 'quantity', e.target.value)}
                                className="w-full rounded-lg border border-slate-300 px-2 py-1.5 text-xs font-mono-numbers text-slate-900 text-right outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white font-bold"
                              />
                            </td>

                            {/* Unit */}
                            <td className="py-2 px-2 text-center">
                              <input
                                type="text"
                                list={`cash-units-${idx}`}
                                value={it.unit}
                                onChange={(e) => handleItemChange(idx, 'unit', e.target.value)}
                                className="w-full rounded-lg border border-slate-300 bg-white px-2 py-1.5 text-xs text-center font-semibold text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                                placeholder="Unit"
                              />
                              <datalist id={`cash-units-${idx}`}>
                                {allUnitOptions.map((u) => (
                                  <option key={u} value={u} />
                                ))}
                              </datalist>
                            </td>

                            {/* Crate Size dropdown */}
                            <td className="py-2 px-2 text-center">
                              {isCrateUnit(it.unit) ? (
                                <select
                                  value={it.crateSize ?? ''}
                                  onChange={(e) => handleItemChange(idx, 'crateSize', e.target.value)}
                                  className="w-full rounded-lg border border-sky-300 bg-sky-50/50 px-2 py-1.5 text-xs text-center font-mono-numbers font-bold text-sky-900 outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                                >
                                  <option value="">Auto</option>
                                  {availableCrateSizes.map((s) => (
                                    <option key={s} value={s}>
                                      {s} KG
                                    </option>
                                  ))}
                                </select>
                              ) : (
                                <span className="text-slate-400 text-[11px]">-</span>
                              )}
                            </td>

                            {/* KG (Customer actual weight / Weight) */}
                            <td className="py-2 px-2 text-right">
                              <input
                                type="number"
                                min="0"
                                step="any"
                                placeholder="0"
                                value={it.kg === 0 ? '' : (it.kg ?? '')}
                                onChange={(e) => handleItemChange(idx, 'kg', e.target.value)}
                                className="w-full rounded-lg border border-slate-300 px-2 py-1.5 text-xs font-mono-numbers font-bold text-slate-900 text-right outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                              />
                            </td>

                            {/* Rate */}
                            <td className="py-2 px-2 text-right">
                              <input
                                type="number"
                                min="0"
                                step="any"
                                placeholder="Rate"
                                value={it.rate === 0 ? '' : it.rate}
                                onChange={(e) => handleItemChange(idx, 'rate', e.target.value)}
                                className="w-full rounded-lg border border-slate-300 px-2 py-1.5 text-xs font-mono-numbers text-slate-900 text-right outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white font-medium"
                              />
                            </td>

                            {/* Amount */}
                            <td className="py-2 px-2 text-right font-mono font-bold text-slate-900 dark:text-white">
                              {formatCurrency(it.amount)}
                            </td>

                            <td className="py-2 px-1 text-center">
                              {items.length > 1 && (
                                <button
                                  type="button"
                                  onClick={() => handleRemoveItem(idx)}
                                  className="text-slate-400 hover:text-rose-600 p-1"
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                </button>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Balance Crate Section (Requirement 3) */}
              <div className="rounded-lg border border-sky-200 bg-sky-50/50 p-4 dark:border-sky-900/40 dark:bg-sky-950/20">
                <div className="mb-2 flex items-center gap-2">
                  <Box className="h-4 w-4 text-sky-600 dark:text-sky-400" />
                  <h4 className="text-xs font-bold uppercase tracking-wider text-sky-900 dark:text-sky-300">
                    Balance Crate Breakdown & Calculations
                  </h4>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="mb-1 block text-xs font-medium text-slate-700 dark:text-slate-300">
                      Default Crate Type
                    </label>
                    <select
                      value={crateTypeId}
                      onChange={(e) => setCrateTypeId(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs text-slate-900 outline-none focus:border-sky-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                    >
                      {crateTypes.map((ct) => (
                        <option key={ct.id} value={ct.id}>
                          {ct.name} ({ct.defaultWeightKg} KG)
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="mb-1 block text-xs font-medium text-slate-700 dark:text-slate-300">
                      Balance Crate OUT (Issued to customer)
                    </label>
                    <input
                      type="number"
                      min="0"
                      placeholder="0"
                      value={crateOut}
                      onChange={(e) => setCrateOut(e.target.value ? Number(e.target.value) : '')}
                      className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-mono-numbers text-slate-900 outline-none focus:border-sky-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="mb-1 block text-xs font-medium text-slate-700 dark:text-slate-300">
                      Balance Crate IN (Returned by customer)
                    </label>
                    <input
                      type="number"
                      min="0"
                      placeholder="0"
                      value={crateIn}
                      onChange={(e) => setCrateIn(e.target.value ? Number(e.target.value) : '')}
                      className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-mono-numbers text-slate-900 outline-none focus:border-sky-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                    />
                  </div>
                </div>

                {/* Balance Crate Breakdown Display as specified in Section 3 */}
                <div className="mt-3 p-2.5 rounded bg-white dark:bg-slate-900 border border-sky-100 dark:border-sky-900 text-xs font-mono">
                  <div className="font-bold text-sky-950 dark:text-sky-200">
                    Balance Crate: {crateSummary.totalBalanceCrates}
                  </div>
                  {crateSummary.breakdown.length > 0 && (
                    <div className="mt-1 flex flex-wrap gap-4 text-sky-800 dark:text-sky-300">
                      {crateSummary.breakdown.map((b) => (
                        <span key={b.weightKg} className="bg-sky-50 dark:bg-sky-950 px-2 py-0.5 rounded border border-sky-200 dark:border-sky-800">
                          {b.weightKg}kg = {b.count}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Expenses */}
              <div className="rounded-lg border border-slate-200 p-4 dark:border-slate-800">
                <div className="mb-2 flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                    Cash Sale Expenses (Hamali, Freight, etc.)
                  </span>
                  <button
                    type="button"
                    onClick={handleAddExpense}
                    className="flex items-center gap-1 text-xs font-semibold text-emerald-600 hover:text-emerald-700"
                  >
                    <Plus className="h-3 w-3" /> + Add Expense
                  </button>
                </div>

                <div className="space-y-2">
                  {expenses.map((exp, idx) => (
                    <div key={exp.id || idx} className="flex items-center gap-2">
                      <input
                        type="text"
                        value={exp.name}
                        onChange={(e) => handleExpenseChange(idx, 'name', e.target.value)}
                        placeholder="Expense Name (Freight, Hamali, Other)"
                        className="flex-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                      />
                      <div className="relative w-32">
                        <span className="absolute left-2.5 top-1.5 text-xs text-slate-400">₹</span>
                        <input
                          type="number"
                          min="0"
                          step="any"
                          value={exp.amount === 0 ? '' : exp.amount}
                          onChange={(e) => handleExpenseChange(idx, 'amount', e.target.value)}
                          className="w-full rounded-lg border border-slate-300 pl-6 pr-2 py-1.5 text-xs font-mono-numbers text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveExpense(idx)}
                        className="text-slate-400 hover:text-rose-600 p-1"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Totals Summary */}
              <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-4 dark:border-slate-800 dark:bg-slate-800/40">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
                  <div>
                    <span className="text-[11px] text-slate-500">Items Total</span>
                    <div className="font-mono-numbers text-sm font-bold text-slate-800 dark:text-slate-200">
                      {formatCurrency(productTotal)}
                    </div>
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-500">+ Expenses</span>
                    <div className="font-mono-numbers text-sm font-bold text-slate-800 dark:text-slate-200">
                      +{formatCurrency(expenseTotal)}
                    </div>
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-500">Calculated Bill</span>
                    <div className="font-mono-numbers text-sm font-bold text-slate-800 dark:text-slate-200">
                      {formatCurrency(totalAmount)}
                    </div>
                  </div>
                  <div>
                    <span className="text-[11px] text-emerald-600 font-bold uppercase">Final Cash Amount</span>
                    <div className="font-mono-numbers text-base font-black text-emerald-600 dark:text-emerald-400">
                      {formatCurrency(finalAmount)}
                    </div>
                  </div>
                </div>

                {/* Manual Amount Override */}
                <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs">
                  <label className="flex items-center gap-2 cursor-pointer text-slate-700 dark:text-slate-300">
                    <input
                      type="checkbox"
                      checked={isManualAmountOverridden}
                      onChange={(e) => setIsManualAmountOverridden(e.target.checked)}
                      className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                    />
                    <span>Adjust final cash bill amount manually</span>
                  </label>
                  {isManualAmountOverridden && (
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-slate-600 dark:text-slate-400">Fixed Total: ₹</span>
                      <input
                        type="number"
                        min="0"
                        step="any"
                        placeholder="Manual Amount"
                        value={manualAmount}
                        onChange={(e) => setManualAmount(e.target.value ? Number(e.target.value) : '')}
                        className="w-32 rounded-lg border-2 border-emerald-500 px-2.5 py-1 text-xs font-mono-numbers font-bold text-slate-900 outline-none dark:bg-slate-800 dark:text-white"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Notes / Auction Remarks
                </label>
                <input
                  type="text"
                  placeholder="e.g. Counter cash, Spot settlement"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-xs text-slate-900 outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              {/* Footer Controls */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsPrintModalOpen(true)}
                  className="flex items-center gap-1.5 rounded-lg border border-emerald-600 px-3.5 py-2 text-xs font-semibold text-emerald-700 hover:bg-emerald-50 dark:text-emerald-400 dark:hover:bg-emerald-950/30 cursor-pointer"
                >
                  <Printer className="h-3.5 w-3.5" /> Preview / Print Bill
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="rounded-lg border border-slate-300 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800 cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="rounded-lg bg-emerald-600 px-5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-emerald-700 cursor-pointer"
                  >
                    {editItem ? 'Update Cash Sale' : 'Save Cash Sale'}
                  </button>
                </div>
              </div>
            </form>
          )}
        </div>
      </div>

      <AddFruitModal
        isOpen={isAddFruitOpen}
        onClose={() => setIsAddFruitOpen(false)}
        onFruitCreated={(f) => {
          handleAddItem();
        }}
      />

      <AddCustomerModal
        isOpen={isAddCustomerOpen}
        onClose={() => setIsAddCustomerOpen(false)}
        onCustomerCreated={(c) => setCustomerId(c.id)}
      />

      {isPrintModalOpen && (
        <CashSalePrintModal
          isOpen={isPrintModalOpen}
          onClose={() => setIsPrintModalOpen(false)}
          cashSale={currentSaleRecord}
        />
      )}
    </>
  );
};
