import React, { useState, useEffect, useRef } from 'react';
import { Fruit } from '../../types';
import { db } from '../../services/db';
import { getFruitEffectivePrice } from '../../utils/fruitUtils';
import { FruitBadge } from './FruitIconHelper';
import { Apple, Search, Check } from 'lucide-react';

interface FruitAutocompleteProps {
  valueFruitId: string;
  valueFruitName: string;
  onChange: (fruit: Fruit | null) => void;
  onEnterNext?: () => void;
  placeholder?: string;
  hasError?: boolean;
  disabled?: boolean;
}

export const FruitAutocomplete: React.FC<FruitAutocompleteProps> = ({
  valueFruitId,
  valueFruitName,
  onChange,
  onEnterNext,
  placeholder = 'Type fruit name to search...',
  hasError = false,
  disabled = false,
}) => {
  // Dynamically load fruits from Fruit/Item Master
  const fruits = db.getFruits();
  const selectedFruit =
    fruits.find(
      (f) =>
        f.id === valueFruitId ||
        (valueFruitName && f.name.toLowerCase() === valueFruitName.toLowerCase())
    ) || null;

  const [searchTerm, setSearchTerm] = useState(
    valueFruitName || (selectedFruit ? selectedFruit.name : '')
  );
  const [isOpen, setIsOpen] = useState(false);
  const [highlightedIndex, setHighlightedIndex] = useState(0);

  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Sync internal search input if external value changes
  useEffect(() => {
    if (valueFruitName) {
      setSearchTerm(valueFruitName);
    } else if (selectedFruit) {
      setSearchTerm(selectedFruit.name);
    } else if (!valueFruitId && !valueFruitName) {
      setSearchTerm('');
    }
  }, [valueFruitId, valueFruitName, selectedFruit]);

  // Case-insensitive partial matching across fruit name, category, or ID
  const query = searchTerm.trim().toLowerCase();
  const matchingFruits = query
    ? fruits.filter(
        (f) =>
          f.name.toLowerCase().includes(query) ||
          (f.category ? f.category.toLowerCase().includes(query) : false) ||
          f.id.toLowerCase().includes(query)
      )
    : [];

  useEffect(() => {
    setHighlightedIndex(0);
  }, [searchTerm]);

  // Close dropdown on outside click, reverting or clearing safely
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
        if (selectedFruit) {
          setSearchTerm(selectedFruit.name);
        } else if (valueFruitName) {
          setSearchTerm(valueFruitName);
        } else {
          setSearchTerm('');
          onChange(null);
        }
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, [selectedFruit, valueFruitName, onChange]);

  const handleSelect = (fruit: Fruit) => {
    setSearchTerm(fruit.name);
    onChange(fruit);
    setIsOpen(false);
    if (onEnterNext) {
      setTimeout(() => onEnterNext(), 30);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (!isOpen && query.length > 0) {
        setIsOpen(true);
      } else if (isOpen) {
        setHighlightedIndex((prev) =>
          prev < matchingFruits.length - 1 ? prev + 1 : prev
        );
      }
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (isOpen) {
        setHighlightedIndex((prev) => (prev > 0 ? prev - 1 : 0));
      }
    } else if (e.key === 'Enter') {
      if (isOpen && matchingFruits.length > 0) {
        e.preventDefault();
        const picked = matchingFruits[highlightedIndex] || matchingFruits[0];
        if (picked) {
          handleSelect(picked);
        }
      } else if (!isOpen && onEnterNext) {
        onEnterNext();
      }
    } else if (e.key === 'Escape') {
      setIsOpen(false);
      if (selectedFruit) {
        setSearchTerm(selectedFruit.name);
      } else {
        setSearchTerm('');
      }
    }
  };

  return (
    <div ref={containerRef} className="relative w-full">
      <div className="relative flex items-center">
        {selectedFruit && (
          <div className="absolute left-2.5 z-10 pointer-events-none">
            <FruitBadge
              fruitIcon={selectedFruit.fruitIcon}
              fruitName={selectedFruit.name}
              size="xs"
            />
          </div>
        )}
        <input
          ref={inputRef}
          type="text"
          value={searchTerm}
          disabled={disabled}
          placeholder={placeholder}
          onFocus={() => {
            if (searchTerm.trim().length > 0) {
              setIsOpen(true);
            }
          }}
          onChange={(e) => {
            const val = e.target.value;
            setSearchTerm(val);
            if (val.trim().length > 0) {
              setIsOpen(true);
            } else {
              setIsOpen(false);
              onChange(null);
            }
          }}
          onKeyDown={handleKeyDown}
          className={`w-full rounded-lg px-3 py-2 text-sm text-slate-800 outline-none transition-all placeholder:text-slate-400 font-medium ${
            selectedFruit ? 'pl-9' : ''
          } ${
            hasError
              ? 'border border-rose-500 bg-rose-50/50 text-rose-900 shadow-inner'
              : 'neu-inset'
          }`}
        />
      </div>

      {isOpen && query.length > 0 && (
        <div className="neu-dropdown absolute left-0 top-full z-50 mt-1 max-h-56 w-full min-w-[260px] overflow-y-auto p-1 text-xs animate-in fade-in slide-in-from-top-1 duration-150 shadow-lg bg-white dark:bg-[#131d31] border border-slate-200 dark:border-slate-700 rounded-lg">
          {matchingFruits.length === 0 ? (
            <div className="p-3 text-center text-slate-400 dark:text-slate-500">
              <Apple className="mx-auto h-5 w-5 mb-1 opacity-50 text-slate-400 dark:text-slate-500" />
              <span>No matching items found</span>
            </div>
          ) : (
            matchingFruits.map((fruit, idx) => {
              const isSelected = fruit.id === valueFruitId;
              const isHighlighted = idx === highlightedIndex;
              return (
                <div
                  key={fruit.id}
                  onMouseDown={(e) => {
                    e.preventDefault();
                    handleSelect(fruit);
                  }}
                  onMouseEnter={() => setHighlightedIndex(idx)}
                  className={`flex cursor-pointer items-center justify-between px-3 py-2 rounded-lg transition-colors ${
                    isHighlighted
                      ? 'bg-blue-600 text-white'
                      : isSelected
                      ? 'bg-blue-50 dark:bg-blue-900/50 text-blue-900 dark:text-blue-200 font-bold'
                      : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100/70 dark:hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <FruitBadge
                      fruitIcon={fruit.fruitIcon}
                      fruitName={fruit.name}
                      size="sm"
                    />
                    <span className="font-semibold">{fruit.name}</span>
                    {fruit.category && (
                      <span
                        className={`text-[10px] px-1 rounded ${
                          isHighlighted
                            ? 'bg-blue-500 text-white'
                            : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        {fruit.category}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`font-mono-numbers text-[11px] ${
                        isHighlighted ? 'text-blue-100' : 'text-slate-500 dark:text-slate-400'
                      }`}
                    >
                      ₹{getFruitEffectivePrice(fruit)}/{fruit.unit || fruit.defaultUnit}
                    </span>
                    {isSelected && (
                      <Check
                        className={`h-3.5 w-3.5 ${
                          isHighlighted ? 'text-white' : 'text-blue-600 dark:text-blue-400'
                        }`}
                      />
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
};
