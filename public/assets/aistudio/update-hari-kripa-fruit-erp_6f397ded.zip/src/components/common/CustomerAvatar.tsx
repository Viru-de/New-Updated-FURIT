import React from 'react';
import { User } from 'lucide-react';

interface CustomerAvatarProps {
  photo?: string;
  name: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export const CustomerAvatar: React.FC<CustomerAvatarProps> = ({
  photo,
  name,
  size = 'md',
  className = '',
}) => {
  const sizeClasses = {
    xs: 'w-6 h-6 text-[10px]',
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm font-semibold',
    lg: 'w-12 h-12 text-base font-bold',
    xl: 'w-16 h-16 text-lg font-bold',
  }[size];

  const iconSizes = {
    xs: 'w-3 h-3',
    sm: 'w-4 h-4',
    md: 'w-5 h-5',
    lg: 'w-6 h-6',
    xl: 'w-8 h-8',
  }[size];

  // If customer has an uploaded photo
  if (photo && (photo.startsWith('data:') || photo.startsWith('/') || photo.startsWith('http'))) {
    return (
      <div
        className={`inline-flex shrink-0 items-center justify-center rounded-lg border border-slate-200 bg-white overflow-hidden shadow-2xs ${sizeClasses} ${className}`}
      >
        <img
          src={photo}
          alt={name}
          className="w-full h-full object-cover"
          loading="lazy"
        />
      </div>
    );
  }

  // Consistent pleasant background color derived from name
  const initials = (name || '?')
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((s) => s[0].toUpperCase())
    .join('');

  return (
    <div
      className={`inline-flex shrink-0 items-center justify-center rounded-lg border border-slate-200 bg-slate-100 text-slate-700 shadow-2xs select-none ${sizeClasses} ${className}`}
      title={name}
    >
      {initials ? (
        <span>{initials}</span>
      ) : (
        <User className={`${iconSizes} text-slate-400`} />
      )}
    </div>
  );
};
