import React, { useState, useEffect, useRef } from 'react';
import { Customer } from '../../types';
import { db } from '../../services/db';
import { CustomerAvatar } from './CustomerAvatar';
import { Users, Search, Phone, MapPin, Check } from 'lucide-react';

interface CustomerAutocompleteProps {
  valueCustomerId: string;
  onChange: (customer: Customer | null) => void;
  onEnterNext?: () => void;
  placeholder?: string;
  hasError?: boolean;
  disabled?: boolean;
  autoFocus?: boolean;
}

export const CustomerAutocomplete: React.FC<CustomerAutocompleteProps> = ({
  valueCustomerId,
  onChange,
  onEnterNext,
  placeholder = 'Type customer name, code or mobile...',
  hasError = false,
  disabled = false,
  autoFocus = false,
}) => {
  const customers = db.getCustomers();
  const selectedCustomer = customers.find((c) => c.id === valueCustomerId) || null;

  const [searchTerm, setSearchTerm] = useState(selectedCustomer ? selectedCustomer.name : '');
  const [isOpen, setIsOpen] = useState(false);
  const [highlightedIndex, setHighlightedIndex] = useState(0);

  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Sync internal search input if selectedCustomer changes from outside
  useEffect(() => {
    if (selectedCustomer) {
      setSearchTerm(selectedCustomer.name);
    } else if (!valueCustomerId) {
      setSearchTerm('');
    }
  }, [valueCustomerId, selectedCustomer]);

  // Filter matching customers: match name, id, mobile, city, altMobile
  const query = searchTerm.trim().toLowerCase();
  const matchingCustomers = query
    ? customers.filter((c) => {
        const nameMatch = c.name.toLowerCase().includes(query);
        const mobileMatch = c.mobile && c.mobile.includes(query);
        const idMatch = c.id.toLowerCase().includes(query);
        const cityMatch = c.city && c.city.toLowerCase().includes(query);
        return nameMatch || mobileMatch || idMatch || cityMatch;
      })
    : customers;

  useEffect(() => {
    setHighlightedIndex(0);
  }, [searchTerm]);

  // Close dropdown on click outside
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
        // If user typed something but didn't select, revert to currently selected customer name
        if (selectedCustomer) {
          setSearchTerm(selectedCustomer.name);
        } else {
          setSearchTerm('');
          onChange(null);
        }
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, [selectedCustomer, onChange]);

  const handleSelect = (customer: Customer) => {
    setSearchTerm(customer.name);
    onChange(customer);
    setIsOpen(false);
    if (onEnterNext) {
      setTimeout(() => onEnterNext(), 30);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (!isOpen) {
        setIsOpen(true);
      } else {
        setHighlightedIndex((prev) =>
          prev < matchingCustomers.length - 1 ? prev + 1 : prev
        );
      }
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (isOpen) {
        setHighlightedIndex((prev) => (prev > 0 ? prev - 1 : 0));
      }
    } else if (e.key === 'Enter') {
      if (isOpen && matchingCustomers.length > 0) {
        e.preventDefault();
        const picked = matchingCustomers[highlightedIndex] || matchingCustomers[0];
        if (picked) {
          handleSelect(picked);
        }
      } else if (!isOpen && onEnterNext) {
        onEnterNext();
      }
    } else if (e.key === 'Escape') {
      setIsOpen(false);
      if (selectedCustomer) {
        setSearchTerm(selectedCustomer.name);
      }
    }
  };

  return (
    <div ref={containerRef} className="relative w-full">
      <div className="relative flex items-center">
        {selectedCustomer && (
          <div className="absolute left-2.5 z-10 pointer-events-none">
            <CustomerAvatar
              photo={selectedCustomer.photo}
              name={selectedCustomer.name}
              size="xs"
            />
          </div>
        )}
        <input
          ref={inputRef}
          type="text"
          value={searchTerm}
          autoFocus={autoFocus}
          disabled={disabled}
          placeholder={placeholder}
          onFocus={() => setIsOpen(true)}
          onChange={(e) => {
            setSearchTerm(e.target.value);
            setIsOpen(true);
            if (!e.target.value) {
              onChange(null);
            }
          }}
          onKeyDown={handleKeyDown}
          className={`w-full rounded-lg px-3 py-2 text-sm text-slate-800 outline-none transition-all placeholder:text-slate-400 font-medium ${
            selectedCustomer ? 'pl-9' : ''
          } ${
            hasError
              ? 'border border-rose-500 bg-rose-50/50 text-rose-900 shadow-inner'
              : 'neu-inset'
          }`}
        />
        {selectedCustomer && (
          <span className="absolute right-2.5 top-1/2 -translate-y-1/2 flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-100/70 px-1.5 py-0.5 rounded pointer-events-none">
            <Check className="h-3 w-3" />
            <span>ID: {selectedCustomer.id}</span>
          </span>
        )}
      </div>

      {/* Dropdown suggestions */}
      {isOpen && (
        <div
          ref={dropdownRef}
          className="neu-dropdown absolute left-0 top-full z-50 mt-1 max-h-60 w-full min-w-[280px] overflow-y-auto p-1 text-xs animate-in fade-in slide-in-from-top-1 duration-150"
        >
          {matchingCustomers.length === 0 ? (
            <div className="p-3 text-center text-slate-400">
              <Users className="mx-auto h-5 w-5 mb-1 opacity-50" />
              <span>No matching customer in Directory</span>
            </div>
          ) : (
            matchingCustomers.map((cust, idx) => {
              const isSelected = cust.id === valueCustomerId;
              const isHighlighted = idx === highlightedIndex;
              return (
                <div
                  key={cust.id}
                  onMouseDown={(e) => {
                    e.preventDefault(); // prevent input blur before select
                    handleSelect(cust);
                  }}
                  onMouseEnter={() => setHighlightedIndex(idx)}
                  className={`flex cursor-pointer items-center justify-between px-3 py-2 rounded-lg transition-colors ${
                    isHighlighted
                      ? 'bg-blue-600 text-white'
                      : isSelected
                      ? 'bg-blue-50 dark:bg-blue-900/50 text-blue-900 dark:text-blue-200 font-bold'
                      : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100/70 dark:hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <CustomerAvatar
                      photo={cust.photo}
                      name={cust.name}
                      size="sm"
                    />
                    <div className="flex flex-col min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm truncate">{cust.name}</span>
                        <span
                          className={`text-[10px] px-1 rounded shrink-0 ${
                            isHighlighted
                              ? 'bg-blue-500 text-white'
                              : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                          }`}
                        >
                          {cust.id}
                        </span>
                      </div>
                      <div
                        className={`flex items-center gap-2 text-[11px] mt-0.5 ${
                          isHighlighted ? 'text-blue-100' : 'text-slate-400'
                        }`}
                      >
                        {cust.mobile && (
                          <span className="flex items-center gap-0.5">
                            <Phone className="h-3 w-3" /> {cust.mobile}
                          </span>
                        )}
                        {cust.city && (
                          <span className="flex items-center gap-0.5">
                            <MapPin className="h-3 w-3" /> {cust.city}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {isSelected && (
                    <Check
                      className={`h-4 w-4 shrink-0 ${
                        isHighlighted ? 'text-white' : 'text-blue-600'
                      }`}
                    />
                  )}
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
};
