/**
 * Hari Kripa Fruit ERP
 * Wholesale Fruit Market Mandi Accounting System
 */

import React, { useState, useEffect } from 'react';
import { db } from './services/db';
import { Bill, User } from './types';
import { LoginView } from './components/auth/LoginView';
import { TopNavbar } from './components/layout/TopNavbar';
import { DashboardView } from './components/dashboard/DashboardView';
import { SaleProceedsListView } from './components/accounts/SaleProceedsListView';
import { CashSaleListView } from './components/accounts/CashSaleListView';
import { CreditSaleListView } from './components/accounts/CreditSaleListView';
import { ReceiptListView } from './components/accounts/ReceiptListView';
import { SaleProceedsLedgerView } from './components/accounts/SaleProceedsLedgerView';
import { CustomerLedgerView } from './components/accounts/CustomerLedgerView';
import { CrateStatementView } from './components/accounts/CrateStatementView';
import { CustomerDirectoryView } from './components/master/CustomerDirectoryView';
import { WholesaleDirectoryView } from './components/master/WholesaleDirectoryView';
import { FruitMasterView } from './components/master/FruitMasterView';
import { CreateBillView } from './components/billing/CreateBillView';
import { BillHistoryView } from './components/billing/BillHistoryView';
import { CompanyBillProfilesView } from './components/billing/CompanyBillProfilesView';
import { GroupSaleView } from './components/billing/GroupSaleView';
import { ReportsView } from './components/reports/ReportsView';
import { SettingsView } from './components/settings/SettingsView';
import { TrashView } from './components/master/TrashView';

// Modals
import { SaleProceedsModal } from './components/accounts/SaleProceedsModal';
import { CashSaleModal } from './components/accounts/CashSaleModal';
import { CreditSaleModal } from './components/accounts/CreditSaleModal';
import { ReceiptModal } from './components/accounts/ReceiptModal';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(db.getActiveUser());
  const [currentView, setCurrentView] = useState<string>('dashboard');
  const [, setDbVersion] = useState<number>(0);

  const [reportTab, setReportTab] = useState<
    'dailySales' | 'customerOutstanding' | 'vendorOutstanding' | 'expenses' | 'profit' | 'crates'
  >('dailySales');

  const [settingsTab, setSettingsTab] = useState<
    'general' | 'profiles' | 'units' | 'crates' | 'backup'
  >('general');

  // Cross-navigation context
  const [targetCustomerId, setTargetCustomerId] = useState<string | undefined>(undefined);
  const [billToEdit, setBillToEdit] = useState<Bill | null>(null);

  // Quick Action Modals
  const [quickSaleProceedsOpen, setQuickSaleProceedsOpen] = useState(false);
  const [quickCashSaleOpen, setQuickCashSaleOpen] = useState(false);
  const [quickCreditSaleOpen, setQuickCreditSaleOpen] = useState(false);
  const [quickReceiptOpen, setQuickReceiptOpen] = useState(false);

  // Subscribe to reactive database changes
  useEffect(() => {
    const unsubscribe = db.subscribe(() => {
      setDbVersion((v) => v + 1);
    });
    return unsubscribe;
  }, []);

  if (!currentUser) {
    return <LoginView onLoginSuccess={(u) => setCurrentUser(u)} />;
  }

  const handleLogout = () => {
    db.setActiveUser(null);
    setCurrentUser(null);
  };

  const handleNavigate = (view: string, subParam?: string) => {
    if (view === 'reports' && subParam) {
      setReportTab(subParam as any);
      setCurrentView('reports');
      return;
    }
    if (view === 'settings' && subParam) {
      setSettingsTab(subParam as any);
      setCurrentView('settings');
      return;
    }
    if (subParam && view !== 'settings' && view !== 'reports') {
      setTargetCustomerId(subParam);
    }
    if (view === 'createBill') {
      setBillToEdit(null);
    }
    setCurrentView(view);
  };

  const handleEditBill = (bill: Bill) => {
    setBillToEdit(bill);
    setCurrentView('createBill');
  };

  return (
    <div className="min-h-screen bg-slate-100/75 dark:bg-[#0b1120] text-slate-800 dark:text-slate-100 flex flex-col selection:bg-blue-100 selection:text-blue-900 overflow-x-hidden min-w-0 transition-colors duration-150">
      {/* Top Header & Horizontal Navigation Menu */}
      <TopNavbar
        currentView={currentView}
        reportSubTab={reportTab}
        settingsSubTab={settingsTab}
        onNavigate={handleNavigate}
        onLogout={handleLogout}
      />

      {/* Main Content Area spanning full width under horizontal menu */}
      <div className="flex-1 flex flex-col min-h-screen min-w-0 w-full">
        <main className="flex-1 p-3 sm:p-5 lg:p-6 max-w-7xl w-full mx-auto min-w-0">
          {currentView === 'dashboard' && (
            <DashboardView onNavigate={(v, id) => handleNavigate(v, id)} />
          )}

          {currentView === 'saleProceeds' && <SaleProceedsListView />}

          {currentView === 'cashSales' && (
            <CashSaleListView
              onNavigateToCustomerLedger={(id) => handleNavigate('customerLedger', id)}
            />
          )}

          {currentView === 'creditSales' && (
            <CreditSaleListView
              onNavigateToCustomerLedger={(id) => handleNavigate('customerLedger', id)}
            />
          )}

          {currentView === 'receipts' && (
            <ReceiptListView
              onNavigateToCustomerLedger={(id) => handleNavigate('customerLedger', id)}
            />
          )}

          {currentView === 'saleProceedsLedger' && <SaleProceedsLedgerView />}

          {currentView === 'customerLedger' && (
            <CustomerLedgerView
              initialCustomerId={targetCustomerId}
              onNavigateToCrate={(id) => handleNavigate('crateStatement', id)}
            />
          )}

          {currentView === 'crateStatement' && (
            <CrateStatementView initialCustomerId={targetCustomerId} />
          )}

          {currentView === 'customerDirectory' && (
            <CustomerDirectoryView
              onNavigateToLedger={(id) => handleNavigate('customerLedger', id)}
              onNavigateToCrate={(id) => handleNavigate('crateStatement', id)}
              onNavigateToCreditSales={(id) => handleNavigate('creditSales', id)}
              onNavigateToReceipts={(id) => handleNavigate('receipts', id)}
            />
          )}

          {currentView === 'wholesaleDirectory' && <WholesaleDirectoryView />}

          {currentView === 'fruitMaster' && <FruitMasterView />}

          {currentView === 'trash' && (
            <TrashView
              onNavigateToCustomerLedger={(id) => handleNavigate('customerLedger', id)}
            />
          )}

          {currentView === 'groupSale' && (
            <GroupSaleView
              onNavigateToCustomerLedger={(id) => handleNavigate('customerLedger', id)}
            />
          )}

          {currentView === 'createBill' && (
            <CreateBillView
              editBill={billToEdit}
              onSaved={() => {
                setBillToEdit(null);
                setCurrentView('billHistory');
              }}
              onNavigateToHistory={() => setCurrentView('billHistory')}
            />
          )}

          {currentView === 'billHistory' && (
            <BillHistoryView
              onCreateNewBill={() => {
                setBillToEdit(null);
                setCurrentView('createBill');
              }}
              onEditBill={handleEditBill}
            />
          )}

          {currentView === 'companyProfiles' && <CompanyBillProfilesView />}

          {currentView === 'reports' && (
            <ReportsView
              initialTab={reportTab}
              onTabChange={(t) => setReportTab(t)}
            />
          )}

          {currentView === 'settings' && <SettingsView initialTab={settingsTab} />}
        </main>

        {/* Global Application Footer - Klyia Technology Branding */}
        <footer className="mt-auto py-3.5 px-4 sm:px-6 text-center text-xs text-slate-500 border-t border-slate-300/40 no-print">
          <p className="font-medium">
            Powered by <span className="font-bold text-slate-700">Klyia Technology</span>
          </p>
        </footer>
      </div>

      {/* Global Quick Modals */}
      <SaleProceedsModal
        isOpen={quickSaleProceedsOpen}
        onClose={() => setQuickSaleProceedsOpen(false)}
        onSaved={() => {
          setQuickSaleProceedsOpen(false);
          setCurrentView('saleProceeds');
        }}
      />

      <CashSaleModal
        isOpen={quickCashSaleOpen}
        onClose={() => setQuickCashSaleOpen(false)}
        onSaved={() => {
          setQuickCashSaleOpen(false);
          setCurrentView('cashSales');
        }}
      />

      <CreditSaleModal
        isOpen={quickCreditSaleOpen}
        onClose={() => setQuickCreditSaleOpen(false)}
        onSaved={() => {
          setQuickCreditSaleOpen(false);
          setCurrentView('creditSales');
        }}
      />

      <ReceiptModal
        isOpen={quickReceiptOpen}
        onClose={() => setQuickReceiptOpen(false)}
        onSaved={() => {
          setQuickReceiptOpen(false);
          setCurrentView('receipts');
        }}
      />
    </div>
  );
}
